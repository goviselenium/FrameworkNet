<div align="center">

# 🎭 Playwright .NET 8 Test Automation Framework

**Enterprise-grade Web UI + API test automation — multi-browser, multi-environment, Azure DevOps native.**

[![.NET](https://img.shields.io/badge/.NET-8.0-512BD4?logo=dotnet&logoColor=white)](https://dotnet.microsoft.com/)
[![Playwright](https://img.shields.io/badge/Playwright-1.44-2EAD33?logo=playwright&logoColor=white)](https://playwright.dev/)
[![NUnit](https://img.shields.io/badge/NUnit-4.1-brightgreen)](https://nunit.org/)
[![Azure DevOps](https://img.shields.io/badge/Azure%20DevOps-CI%2FCD-0078D7?logo=azuredevops&logoColor=white)](https://azure.microsoft.com/products/devops)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

*Page Object Model · Parallel Execution · 4-Browser Matrix · API Testing · Screenshot + Trace + Video on Failure · Extent Reports · Serilog*

</div>

---

## 📋 Table of Contents

1. [Overview](#-overview)
2. [Key Features](#-key-features)
3. [Architecture](#-architecture)
4. [Folder Structure](#-folder-structure)
5. [Prerequisites](#-prerequisites)
6. [Local Setup](#-local-setup)
7. [Configuration](#-configuration)
8. [Running Tests Locally](#-running-tests-locally)
9. [Azure DevOps Setup](#-azure-devops-setup)
10. [Pipeline Reference](#-pipeline-reference)
11. [Security & Secrets](#-security--secrets)
12. [Browser Support](#-browser-support)
13. [API Testing](#-api-testing)
14. [Reporting](#-reporting)
15. [Logging](#-logging)
16. [Parallel Execution](#-parallel-execution)
17. [Retry & Trace on Failure](#-retry--trace-on-failure)
18. [Docker & Cross-Browser Matrix](#-docker--cross-browser-matrix)
19. [Adding Pages & Tests](#-adding-pages--tests)
20. [Best Practices](#-best-practices)
21. [Troubleshooting](#-troubleshooting)

---

## 🔍 Overview

This framework delivers **production-ready, scalable** automated testing for web applications using Microsoft Playwright — the modern successor to Selenium with built-in auto-waiting, native API testing, trace viewer, and first-class multi-browser support.

### Technology Stack

| Component | Technology | Version |
|-----------|-----------|---------|
| Language | C# | 12 |
| Runtime | .NET | 8.0 |
| Browser Automation | Microsoft Playwright | 1.44 |
| Test Framework | NUnit | 4.1 |
| Assertions | FluentAssertions | 6.12 |
| Logging | Serilog | 3.1 |
| HTML Reporting | AventStack Extent Reports | 5.0 |
| DI Container | Microsoft.Extensions.DI | 8.0 |
| Configuration | Microsoft.Extensions.Configuration | 8.0 |
| Test Data | Bogus | 35.5 |
| Resilience | Polly | 8.4 |
| CI/CD | Azure DevOps Pipelines | YAML |
| Containers | Docker + official Playwright image | — |

---

## ✨ Key Features

| Feature | Detail |
|---------|--------|
| **4-browser support** | Chromium, Chrome, Firefox, WebKit/Safari, Edge |
| **Built-in auto-wait** | No manual `Wait.Until()` — Playwright waits on every action |
| **API testing built-in** | `IAPIRequestContext` — no HttpClient/RestSharp needed |
| **Hybrid UI + API** | Create data via API → validate in UI (fastest pattern) |
| **Screenshot on failure** | Full-page PNG, attached to NUnit + Extent report |
| **Video on failure** | MP4 recording per test, published as artifact |
| **Playwright Trace** | Full timeline zip (network, DOM, screenshots) — open with `playwright show-trace` |
| **Trace on retry** | Automatically enabled on second+ attempt |
| **Isolated contexts** | Each test gets a fresh `IBrowserContext` — zero cookie bleed |
| **Parallel NUnit** | `[Parallelizable(Fixtures)]` + `ThreadLocal` safety |
| **Multi-environment** | Dev/QA/UAT/Prod via `appsettings.{env}.json` |
| **Zero hardcoded secrets** | Azure Key Vault → Variable Group → Env vars |
| **Cross-browser matrix** | Azure DevOps strategy matrix runs all browsers in parallel |
| **Docker native** | Official `mcr.microsoft.com/playwright/dotnet` image — all browsers pre-installed |
| **Extent Reports** | Dark-theme HTML with screenshots, trace links, video links |
| **TRX for ADO** | Native Azure DevOps Tests tab integration |

---

## 🏛 Architecture

```
╔══════════════════════════════════════════════════════════════════════╗
║                        TEST LAYER                                    ║
║  Tests/Smoke/     → Category("Smoke")    [RetryOnFailure]           ║
║  Tests/Regression → Category("Regression")                          ║
║  Tests/API/       → Category("API")  (no browser context needed)    ║
╚═════════════════════════╦════════════════════════════════════════════╝
                          ║ inherits
╔═════════════════════════▼════════════════════════════════════════════╗
║                      BASE TEST                                       ║
║  [OneTimeSetUp]  → Playwright.Create() + Browser (per fixture)      ║
║  [SetUp]         → New BrowserContext + Page + APIRequestContext     ║
║                    + Start Tracing + Create Extent node              ║
║  [TearDown]      → Screenshot / Trace / Video (on failure)          ║
║                    + Context.Close() + Report                        ║
║  [OneTimeTearDown] → Browser.Close() + Playwright.Dispose()         ║
║                      + Report.Flush()                                ║
╚═════════════════════════╦════════════════════════════════════════════╝
                          ║ uses
╔═════════════════════════▼════════════════════════════════════════════╗
║                   PAGE OBJECT LAYER                                  ║
║  BasePage          → IPage, WaitHelper, Settings, Logger            ║
║  LoginPage         → Role/label/testid locators, fluent actions     ║
║  DashboardPage     → Post-auth page interactions                    ║
║  Components/       → HeaderComponent (reusable across pages)        ║
╚═════════════════════════╦════════════════════════════════════════════╝
                          ║ uses
╔═════════════════════════▼════════════════════════════════════════════╗
║                   UTILITIES LAYER                                    ║
║  BrowserFactory    → Chromium/Chrome/Firefox/WebKit/Edge creation   ║
║  ApiClient         → Typed GET/POST/PUT/PATCH/DELETE wrappers       ║
║  WaitHelper        → Explicit waits (NetworkIdle, URL, element)     ║
║  ScreenshotService → Full-page PNG capture                          ║
║  TraceService      → Playwright trace zip save/stop                 ║
║  LoggingService    → Serilog console + rolling file                 ║
║  ExtentReportService → Thread-safe HTML report                      ║
║  RetryOnFailure    → NUnit IRepeatTest + trace-on-retry signal      ║
║  PlaywrightExtensions → IPage + ILocator extension methods          ║
╚═════════════════════════╦════════════════════════════════════════════╝
                          ║ reads
╔═════════════════════════▼════════════════════════════════════════════╗
║                    CONFIG LAYER                                      ║
║  ConfigurationManager  → Singleton; merges JSON + env vars          ║
║  DependencyContainer   → Microsoft DI root                          ║
║  appsettings.json      → Base defaults                              ║
║  appsettings.{Env}.json → Dev / QA / UAT / Prod overrides          ║
║  Environment Variables  → Pipeline secret injection                 ║
╚══════════════════════════════════════════════════════════════════════╝
```

### Data + Execution Flow

```
Azure DevOps queue run
    │  TEST_ENVIRONMENT=QA  TEST_BROWSER=Chromium  (secrets from Key Vault)
    ▼
ConfigurationManager ──► merges appsettings.json + appsettings.QA.json + env vars
    │
    ▼
DependencyContainer ──► registers AppSettings, BrowserFactory, Logger, Reports
    │
    ▼
NUnit [OneTimeSetUp]
  └─► Playwright.CreateAsync()
  └─► BrowserFactory.CreateBrowserAsync(playwright)  → IBrowser
    │
    ▼
NUnit [SetUp] per test
  └─► BrowserFactory.CreateContextAsync()  → IBrowserContext (isolated)
  └─► context.NewPageAsync()               → IPage
  └─► Playwright.APIRequest.NewContextAsync() → IAPIRequestContext
  └─► new ApiClient(apiContext, ...)
    │
    ▼
Test executes → Page Object actions (Playwright auto-waits on each)
    │
    ▼
NUnit [TearDown]
  └─► if FAILED: Screenshot → Trace → Video → Attach to NUnit + Extent
  └─► context.CloseAsync() → disposes video
    │
    ▼
PublishTestResults@2 → TRX → Azure DevOps Tests tab
PublishPipelineArtifact → Screenshots / Traces / Videos / Extent HTML / Logs
```

---

## 📁 Folder Structure

```
PlaywrightFramework/
│
├── PlaywrightFramework.csproj        # NuGet packages + config copy targets
├── GlobalUsings.cs                   # Assembly-wide global usings
├── Dockerfile                        # Official Playwright image (all browsers)
├── docker-compose.yml                # 4-service browser matrix (local)
├── .gitignore
├── README.md
│
├── pipeline/
│   ├── azure-pipelines.yml           # 4-stage CI/CD (Build→Test→CrossBrowser→Notify)
│   └── templates/
│       └── run-tests-steps.yml       # Reusable steps (single + matrix jobs)
│
└── src/
    │
    ├── Config/                        # ── CONFIGURATION ─────────────────────
    │   ├── appsettings.json           # Base defaults
    │   ├── appsettings.Dev.json       # Dev: headed, slowMo=100, workers=2
    │   ├── appsettings.QA.json        # QA:  headless, trace+video, workers=4
    │   ├── appsettings.UAT.json       # UAT: headless, trace only, workers=2
    │   ├── appsettings.Prod.json      # Prod: headless, minimal footprint
    │   ├── ConfigurationManager.cs    # Singleton env-aware config loader
    │   ├── DependencyContainer.cs     # Microsoft DI composition root
    │   └── playwright.runsettings     # NUnit + dotnet test runner settings
    │
    ├── Models/                        # ── MODELS ─────────────────────────────
    │   └── FrameworkSettings.cs       # AppSettings, Credentials, ApiSettings, ApiResponse<T>
    │
    ├── Pages/                         # ── PAGE OBJECTS ───────────────────────
    │   ├── BasePage.cs                # IPage, WaitHelper, locator builders, interactions
    │   ├── LoginPage.cs               # Role/label/testid selectors, fluent login
    │   ├── DashboardPage.cs           # Post-login page, logout flow
    │   └── Components/
    │       └── HeaderComponent.cs     # Reusable site-wide header
    │
    ├── Tests/                         # ── TEST LAYER ─────────────────────────
    │   ├── AssemblyInfo.cs            # [Parallelizable(Fixtures)] + workers
    │   ├── Base/
    │   │   └── BaseTest.cs            # Full NUnit lifecycle + DI + teardown
    │   ├── Smoke/
    │   │   └── LoginSmokeTests.cs     # TC-AUTH-001…004
    │   ├── Regression/
    │   │   └── DashboardRegressionTests.cs  # TC-DASH-001…003
    │   └── API/
    │       └── UserApiTests.cs        # TC-API-001…004 (incl. hybrid UI+API)
    │
    └── Utilities/                     # ── UTILITIES ──────────────────────────
        ├── BrowserFactory.cs          # Chromium/Chrome/Firefox/WebKit/Edge + context
        ├── ApiClient.cs               # Typed REST client on IAPIRequestContext
        ├── LoggingService.cs          # Serilog: console + rolling file
        ├── ScreenshotService.cs       # Full-page + element PNG capture
        ├── TraceService.cs            # Playwright trace zip lifecycle
        ├── Helpers/
        │   ├── RetryOnFailureAttribute.cs  # IRepeatTest + trace-on-retry signal
        │   └── WaitHelper.cs              # NetworkIdle, URL, element, spinner waits
        ├── Extensions/
        │   └── PlaywrightExtensions.cs    # IPage + ILocator extension methods
        └── Reporting/
            └── ExtentReportService.cs     # Thread-safe dark-theme HTML report
```

---

## 🖥 Prerequisites

### Local Development

| Tool | Version | Verify |
|------|---------|--------|
| .NET SDK | 8.0+ | `dotnet --version` |
| Playwright CLI | Latest | `playwright --version` |
| Docker Desktop | 4.x (optional) | `docker --version` |
| Git | 2.x | `git --version` |

> **No manual browser driver download needed.** Playwright manages its own browser binaries with `playwright install`.

### Install Playwright Browsers

```bash
# Install NuGet packages first
dotnet restore

# Build the project (required before playwright install)
dotnet build

# Install all browsers (Chromium, Firefox, WebKit, Edge) + OS dependencies
dotnet run --project PlaywrightFramework.csproj -- playwright install --with-deps

# Or install a specific browser only
dotnet run -- playwright install chromium --with-deps
dotnet run -- playwright install firefox --with-deps
dotnet run -- playwright install webkit --with-deps
dotnet run -- playwright install msedge --with-deps

# Verify
playwright --version
```

---

## ⚙ Local Setup

```bash
# 1. Clone the repository
git clone https://dev.azure.com/<org>/<project>/_git/playwright-framework
cd playwright-framework

# 2. Restore NuGet packages
dotnet restore

# 3. Build
dotnet build -c Release

# 4. Install Playwright browsers
dotnet run -- playwright install --with-deps

# 5. Set environment (optional — defaults to Dev)
export TEST_ENVIRONMENT=QA           # Linux/macOS
$env:TEST_ENVIRONMENT = "QA"         # PowerShell
set TEST_ENVIRONMENT=QA              # Windows CMD

# 6. Set local credentials (never commit these)
export TEST_ADMIN_USER="admin@example.com"
export TEST_ADMIN_PASSWORD="LocalDevPassword123!"
export TEST_STANDARD_USER="user@example.com"
export TEST_STANDARD_PASSWORD="LocalDevPassword123!"
```

---

## 🔧 Configuration

### appsettings.json (base defaults)

```json
{
  "AppSettings": {
    "Environment":          "Dev",
    "Browser":              "Chromium",
    "Headless":             false,
    "SlowMo":               0,
    "ViewportWidth":        1920,
    "ViewportHeight":       1080,
    "DefaultTimeoutMs":     30000,
    "NavigationTimeoutMs":  60000,
    "ActionTimeoutMs":      15000,
    "ScreenshotOnFailure":  true,
    "VideoOnFailure":       false,
    "TraceOnFailure":       true,
    "MaxRetryCount":        2,
    "ParallelWorkers":      4,
    "BaseUrl":              "https://dev.example.com",
    "ApiBaseUrl":           "https://api.dev.example.com"
  }
}
```

### Environment Profile Summary

| Setting | Dev | QA | UAT | Prod |
|---------|-----|----|-----|------|
| Headless | false | true | true | true |
| SlowMo (ms) | 100 | 0 | 0 | 0 |
| DefaultTimeout (s) | 30 | 45 | 60 | 60 |
| TraceOnFailure | true | true | true | false |
| VideoOnFailure | false | true | false | false |
| Workers | 2 | 4 | 2 | 1 |
| MaxRetry | 1 | 2 | 1 | 1 |

### Override via Environment Variable

Use `__` (double underscore) as section separator:

```bash
AppSettings__Browser=Firefox
AppSettings__Headless=true
AppSettings__DefaultTimeoutMs=60000
AppSettings__BaseUrl=https://staging.example.com
AppSettings__VideoOnFailure=true
```

### Variable Resolution Order

```
appsettings.json
    ↓  (overrides base)
appsettings.{TEST_ENVIRONMENT}.json
    ↓  (overrides JSON)
Environment Variables (__ separator)
    ↓  (overrides all — credentials only)
OverrideCredentialsFromEnv()  ← TEST_ADMIN_USER etc.
```

---

## 🚀 Running Tests Locally

### Basic commands

```bash
# All Smoke tests
dotnet test --filter "Category=Smoke"

# All Regression tests
dotnet test --filter "Category=Regression"

# API tests only (no browser)
dotnet test --filter "Category=API"

# Smoke + Regression
dotnet test --filter "Category=Smoke|Category=Regression"

# Specific test class
dotnet test --filter "FullyQualifiedName~LoginSmokeTests"

# Single test method
dotnet test --filter "FullyQualifiedName~Login_WithValidCredentials_ShouldRedirectToDashboard"
```

### With environment + browser

```bash
# QA, Chromium, headless
TEST_ENVIRONMENT=QA TEST_BROWSER=Chromium TEST_HEADLESS=true \
dotnet test --filter "Category=Smoke" \
            --logger "trx;LogFileName=smoke-qa-chromium.trx" \
            --results-directory ./TestResults

# Dev, headed Firefox (for debugging)
TEST_ENVIRONMENT=Dev TEST_BROWSER=Firefox TEST_HEADLESS=false \
dotnet test --filter "Category=Smoke"

# UAT, Edge, headless
TEST_ENVIRONMENT=UAT TEST_BROWSER=Edge TEST_HEADLESS=true \
dotnet test --filter "Category=Regression"

# WebKit / Safari simulation
TEST_BROWSER=WebKit TEST_HEADLESS=true \
dotnet test --filter "Category=Smoke"
```

### With parallel workers

```bash
# Override worker count at runtime
dotnet test --filter "Category=Regression" \
            -- NUnit.NumberOfTestWorkers=8
```

### Run all browsers sequentially (bash)

```bash
#!/bin/bash
for BROWSER in Chromium Firefox WebKit Edge; do
  echo "▶ $BROWSER"
  TEST_BROWSER=$BROWSER TEST_HEADLESS=true \
  dotnet test --filter "Category=Smoke" \
              --logger "trx;LogFileName=smoke_${BROWSER}.trx" \
              --results-directory ./TestResults/$BROWSER
done
```

### View Playwright trace

```bash
# After a failed test, find the trace zip:
playwright show-trace TestResults/Traces/Login_WithInvalidPassword_*.zip
```

---

## 🔷 Azure DevOps Setup

### Step 1 — Create Azure Key Vault

```bash
az login
az group create --name rg-playwright-automation --location eastus

az keyvault create \
  --name kv-playwright-tests \
  --resource-group rg-playwright-automation \
  --location eastus

az keyvault secret set --vault-name kv-playwright-tests --name TEST-ADMIN-USER     --value "admin@company.com"
az keyvault secret set --vault-name kv-playwright-tests --name TEST-ADMIN-PASSWORD --value "<secure-password>"
az keyvault secret set --vault-name kv-playwright-tests --name TEST-STANDARD-USER  --value "user@company.com"
az keyvault secret set --vault-name kv-playwright-tests --name TEST-STANDARD-PASSWORD --value "<secure-password>"

# Grant ADO service principal access
az keyvault set-policy \
  --name kv-playwright-tests \
  --spn <ado-service-principal-app-id> \
  --secret-permissions get list
```

### Step 2 — Create Variable Group

1. **Pipelines → Library → + Variable group**
2. Name: `playwright-framework-secrets`
3. Toggle **Link secrets from an Azure Key Vault** → ON
4. Select `kv-playwright-tests` → Add all 4 secrets
5. **Save → Pipeline permissions → Add your pipeline**

### Step 3 — Create Pipeline

1. **Pipelines → New pipeline → Azure Repos Git**
2. Select your repository
3. **Existing Azure Pipelines YAML file** → `/pipeline/azure-pipelines.yml`
4. **Save** (do not run yet)

### Step 4 — Set Pipeline Variables

| Variable | Value | Settable at queue | Secret |
|----------|-------|-------------------|--------|
| `TEST_ENVIRONMENT` | `QA` | ✅ | ❌ |
| `TEST_BROWSER` | `Chromium` | ✅ | ❌ |
| `TEST_HEADLESS` | `true` | ✅ | ❌ |
| `TEST_CATEGORY` | `Smoke` | ✅ | ❌ |
| `TEST_WORKERS` | `4` | ✅ | ❌ |

### Step 5 — Configure Branch Policies

**Repos → Branches → `main` → Branch policies:**
- Require ≥1 reviewer
- Require linked work item
- **Build validation** → select pipeline, Test Category: `Smoke`

### Step 6 — Run and Verify

Queue a run → select `environment: QA`, `browser: Chromium`, `testCategory: Smoke`

After completion check:
- ✅ **Tests** tab → NUnit TRX results with pass/fail
- ✅ **Artifacts** → `screenshots-*`, `traces-*`, `html-report-*`, `logs-*`, `videos-*`
- ✅ Failing test → download trace → `playwright show-trace trace.zip`

---

## 📋 Pipeline Reference

### Stages

| Stage | Condition | Purpose |
|-------|-----------|---------|
| **Build** | Always | Restore → Build → Publish artifact |
| **Test** | `runAllBrowsers=false` | Single browser test run |
| **CrossBrowserTest** | `runAllBrowsers=true` | 4-browser matrix (Chromium/Firefox/WebKit/Edge) |
| **Notify** | Always | Teams/Slack notification (optional) |

### Triggers

| Trigger | Default Category | Default Env |
|---------|-----------------|------------|
| PR to `main`/`develop` | Smoke | QA |
| Push to `main` | Smoke | QA |
| Push to `release/*` | Smoke | UAT |
| Nightly 02:00 UTC | Regression | QA |
| Manual | Configurable | Configurable |

### Key `dotnet test` flags

```bash
dotnet test PlaywrightFramework.csproj     \
  --configuration Release                  \
  --no-build                               \
  --filter "Category=Smoke"                \
  --logger "trx;LogFileName=results.trx"   \
  --results-directory TestResults          \
  --settings src/Config/playwright.runsettings \
  -- NUnit.NumberOfTestWorkers=4
```

### Trigger via Azure CLI

```bash
az pipelines run \
  --name "Playwright Framework"            \
  --parameters environment=UAT browser=Firefox testCategory=Regression \
  --org https://dev.azure.com/<org>        \
  --project <project>
```

---

## 🔐 Security & Secrets

**Rules:**
- ✅ All credentials in Azure Key Vault only
- ✅ Key Vault linked to ADO Variable Group → injected as env vars
- ✅ `appsettings.json` Credentials block is intentionally blank
- ❌ No passwords, tokens, or API keys in source control — ever
- ❌ Credential values are never logged (framework logs masked indicators)

**Local development:**

```bash
# .env — add to .gitignore, never commit
TEST_ADMIN_USER=admin@example.com
TEST_ADMIN_PASSWORD=LocalPass123!
TEST_STANDARD_USER=user@example.com
TEST_STANDARD_PASSWORD=LocalPass123!
```

```bash
# Load .env before running
set -a && source .env && set +a
dotnet test --filter "Category=Smoke"
```

---

## 🌐 Browser Support

| Browser | Engine | Notes |
|---------|--------|-------|
| **Chromium** | Blink | Default CI browser. Fastest Playwright execution. |
| **Chrome** | Blink | Real Google Chrome channel. Use for Chrome-specific bugs. |
| **Firefox** | Gecko | Mozilla Firefox. ~10% slower than Chromium. |
| **WebKit** | WebKit | Safari-compatible. Only cross-platform way to test Safari. |
| **Edge** | Blink | Microsoft Edge channel. Same engine as Chromium. |

```bash
TEST_BROWSER=Chromium  dotnet test --filter "Category=Smoke"
TEST_BROWSER=Chrome    dotnet test --filter "Category=Smoke"
TEST_BROWSER=Firefox   dotnet test --filter "Category=Smoke"
TEST_BROWSER=WebKit    dotnet test --filter "Category=Smoke"
TEST_BROWSER=Edge      dotnet test --filter "Category=Smoke"
```

> **Note:** `WebKit` is the only way to test Safari behaviour on non-macOS CI agents — Playwright's WebKit build mimics Safari's rendering engine.

---

## 🔌 API Testing

The framework uses Playwright's built-in `IAPIRequestContext` — no RestSharp, HttpClient, or additional dependencies needed.

### Typed API Client

```csharp
// GET — deserialises response into typed DTO
var response = await Api.GetAsync<UserDto>("/api/users/1",
    headers: new() { ["Authorization"] = $"Bearer {token}" });

response.IsSuccess.Should().BeTrue();
response.StatusCode.Should().Be(200);
response.Data!.Name.Should().Be("Alice");

// POST — sends JSON body
var created = await Api.PostAsync<UserDto>("/api/users", new
{
    name  = "Bob",
    email = "bob@example.com",
    role  = "viewer"
});
created.StatusCode.Should().Be(201);

// DELETE
var deleted = await Api.DeleteAsync($"/api/users/{id}");
deleted.StatusCode.Should().Be(204);
```

### Hybrid UI + API Pattern

```csharp
[Test]
public async Task CreateUserViaApi_ShouldAppearInAdminUi()
{
    // Step 1: Create test data via API (fast, no UI flakiness)
    var response = await Api.PostAsync<JsonElement>("/api/users", new
    {
        name  = "Test User",
        email = "test@example.com"
    });
    response.IsSuccess.Should().BeTrue();

    // Step 2: Verify in UI (what the user actually sees)
    await Page.GotoAsync($"{Settings.BaseUrl}/admin/users");
    await Page.GetByText("test@example.com").IsVisibleAsync()
        .Should().BeTrue(because: "API-created user must appear in the UI");
}
```

### Benefits over standalone HttpClient

| Concern | IAPIRequestContext | HttpClient |
|---------|-------------------|------------|
| Auth cookie sharing | Automatic | Manual cookie jar |
| Network interception | Built-in | External proxy |
| HAR recording | Built-in | Not available |
| Same test session | Yes | No |
| Setup boilerplate | Minimal | Significant |

---

## 📊 Reporting

### 1. NUnit TRX (Azure DevOps native)

Published by `PublishTestResults@2` (format: VSTest). Visible under the **Tests** tab of every pipeline run. Shows:
- Pass / fail / skipped counts per run
- Duration per test
- Error messages and stack traces
- Screenshot attachments (via `TestContext.AddTestAttachment`)
- Trace file links

### 2. Extent HTML Report

Generated by `ExtentReportService` → `TestResults/Reports/TestReport_{Env}_{timestamp}.html`.

Published as artifact: `html-report-{browser}-{env}-{build}`.

Includes: dark-theme dashboard, per-test steps (Info/Pass/Fail/Warning), inline screenshot thumbnails, trace + video links, system info panel (env, browser, OS, machine, timestamp).

```bash
# View locally after a test run
open TestResults/Reports/TestReport_*.html       # macOS
start TestResults/Reports/TestReport_*.html      # Windows
```

### 3. Playwright Trace Viewer

On failure, a `.zip` trace is saved to `TestResults/Traces/`. It contains a full timeline of the test execution including network requests, DOM snapshots, and screenshots at every step.

```bash
# Open trace in browser (interactive timeline)
playwright show-trace TestResults/Traces/Login_WithInvalidPassword_20240523.zip
```

### 4. Test Video

When `VideoOnFailure: true` (QA environment default), an MP4 video of the browser session is recorded and saved to `TestResults/Videos/` on test failure. Published as pipeline artifact `videos-*`.

---

## 📝 Logging

Serilog is configured with two sinks:

| Sink | Level | Purpose |
|------|-------|---------|
| Console | Debug+ | Real-time in Azure DevOps task output |
| Rolling File | Debug+ | `TestResults/Logs/playwright-{date}.log` |

Thread ID is included in every log entry for parallel-safe diagnosis.

**Log format:**
```
[14:32:01 INF] [T12] [QA|Chromium] Test STARTED: LoginSmokeTests.Login_WithValidCredentials
[14:32:01 DBG] [T12] [QA|Chromium] Fill 'testuser@example.com' into: GetByLabel("Username")
[14:32:03 INF] [T12] [QA|Chromium] Screenshot saved: TestResults/Screenshots/Login_...png
[14:32:03 WRN] [T12] [QA|Chromium] Test 'Login_WithInvalidPassword' — attempt 1/2. Retrying...
```

---

## ⚡ Parallel Execution

```csharp
// AssemblyInfo.cs
[assembly: Parallelizable(ParallelScope.Fixtures)]
[assembly: LevelOfParallelism(4)]
```

Each `[TestFixture]` class runs on its own thread. `IPlaywright` and `IBrowser` are created once per fixture. `IBrowserContext` and `IPage` are per-test — fully isolated with no shared state.

```bash
# Override worker count at runtime
dotnet test -- NUnit.NumberOfTestWorkers=8
```

| Environment | Workers | Reason |
|-------------|---------|--------|
| Dev (local) | 2 | Local resource constraints |
| QA (CI) | 4 | Hosted agent: 2 vCPUs |
| UAT | 2 | Stability priority |
| Prod | 1 | Minimal live system footprint |

---

## 🔁 Retry & Trace on Failure

```csharp
[Test, RetryOnFailure]        // uses appsettings MaxRetryCount
[Test, RetryOnFailure(3)]     // explicit override
```

On any retry attempt, `RetryOnFailureAttribute` sets a `TraceOnRetry` signal. `BaseTest.SetUp` detects this and activates Playwright tracing for that attempt — providing a full diagnostic trace exactly when it matters most.

**Use `[RetryOnFailure]` for:**
- Animations / page transitions
- Third-party widget rendering delays
- Network-dependent assertions

**Don't use it for:**
- Tests with known bugs (fix the bug)
- Data mutation tests (risk of duplicate state)
- Tests needing >2 retries (fix the test design)

---

## 🐳 Docker & Cross-Browser Matrix

### Run locally across all browsers

```bash
# Build image and run all 4 browsers
docker compose up --build

# Single browser
docker compose up chromium-tests

# With env vars
TEST_ENVIRONMENT=QA TEST_CATEGORY=Smoke docker compose up
```

### Official Playwright Docker image

```bash
# All browsers pre-installed — no playwright install step needed
docker run --rm \
  -e TEST_ENVIRONMENT=QA \
  -e TEST_BROWSER=Chromium \
  -e TEST_HEADLESS=true \
  -e TEST_STANDARD_USER=user@example.com \
  -e TEST_STANDARD_PASSWORD=securepassword \
  -v "$(pwd)/TestResults:/app/TestResults" \
  mcr.microsoft.com/playwright/dotnet:v1.44.0-jammy \
  dotnet test PlaywrightFramework.dll --filter "Category=Smoke"
```

### Azure DevOps cross-browser matrix

Set `runAllBrowsers=true` at queue time to activate the strategy matrix — all 4 browsers run in parallel jobs:

```yaml
strategy:
  matrix:
    Chromium: { BrowserName: Chromium }
    Firefox:  { BrowserName: Firefox  }
    WebKit:   { BrowserName: WebKit   }
    Edge:     { BrowserName: Edge     }
  maxParallel: 4
```

---

## 🛠 Adding Pages & Tests

### New Page Object

```csharp
public sealed class ProductPage : BasePage
{
    // Playwright-idiomatic locators (role/label/testid preferred)
    private ILocator Title       => GetByRole(AriaRole.Heading, "Product Details");
    private ILocator AddToCart   => GetByRole(AriaRole.Button, "Add to Cart");
    private ILocator PriceLabel  => GetByTestId("product-price");
    private ILocator QtyInput    => GetByLabel("Quantity");

    public ProductPage(IPage page, AppSettings settings, LoggingService log)
        : base(page, settings, log) { }

    protected override string PagePath => "/products";

    // Actions return page objects (fluent chaining)
    public async Task<ProductPage> SetQuantityAsync(int qty)
    {
        await FillAsync(QtyInput, qty.ToString());
        return this;
    }

    public async Task<CartPage> AddToCartAsync()
    {
        Log.Info("Adding product to cart");
        await ClickAsync(AddToCart);
        return new CartPage(Page, Settings, Log);
    }

    // State queries return primitives — no assertions inside pages
    public async Task<string>  GetTitleTextAsync()  => await GetTextAsync(Title);
    public async Task<decimal> GetPriceAsync()
    {
        var raw = await GetTextAsync(PriceLabel);
        return decimal.TryParse(raw.Replace("$", ""), out var p) ? p : 0m;
    }

    public override async Task WaitForPageLoadAsync()
    {
        await base.WaitForPageLoadAsync();
        await Wait.WaitForVisibleAsync(Title);
    }
}
```

### New Test Class

```csharp
[TestFixture]
[Category("Smoke")]
[Category("Product")]
[Parallelizable(ParallelScope.Self)]
public sealed class ProductSmokeTests : BaseTest
{
    private ProductPage _productPage = null!;

    [SetUp]
    public override async Task SetUpAsync()
    {
        await base.SetUpAsync();
        _productPage = new ProductPage(Page, Settings, Log);
        await _productPage.OpenAsync();
    }

    [Test, RetryOnFailure]
    [Description("TC-PROD-001: Product page displays title")]
    public async Task ProductPage_ShouldDisplayTitle()
    {
        var title = await _productPage.GetTitleTextAsync();

        title.Should().NotBeNullOrWhiteSpace(
            because: "every product page must have a visible title");

        Report.LogPass("Product title is displayed ✓");
    }
}
```

---

## ✅ Best Practices

### Locator Priority (most → least resilient)

```csharp
// ✅ Best: role-based (accessible, maps to user perception)
GetByRole(AriaRole.Button, "Submit")
GetByRole(AriaRole.Heading, "Dashboard")

// ✅ Best: test-id (explicit contract with developers)
GetByTestId("login-button")          // data-testid="login-button"

// ✅ Good: label-based (linked to form inputs)
GetByLabel("Email address")
GetByPlaceholder("Enter your email")

// ✅ OK: CSS selector (use when above aren't available)
GetLocator("[data-qa='submit-btn']")
GetLocator(".product-card .price")

// ⚠️ Avoid: positional XPath
Page.Locator("(//button)[2]")        // breaks on DOM changes

// ❌ Never: sleep-based waits
await Task.Delay(3000);              // NEVER — use WaitHelper instead
```

### Playwright vs Thread.Sleep

```csharp
// ✅ Playwright auto-waits — just call the action
await locator.ClickAsync();                   // waits for clickable
await locator.FillAsync("text");              // waits for editable
await locator.IsVisibleAsync();               // waits for attached

// ✅ Explicit wait when needed
await Wait.WaitForNetworkIdleAsync();
await Wait.WaitForUrlContainsAsync("/dashboard");
await Wait.WaitForSpinnerToDisappearAsync();

// ❌ NEVER — no sleep of any kind
await Task.Delay(3000);
Thread.Sleep(3000);
```

### Test Design Rules

```
✅ One logical scenario per test
✅ Arrange / Act / Assert structure
✅ Test names: Method_Condition_ExpectedResult
✅ [Description] attribute on every test
✅ Report.LogPass() at end of every passing test
✅ Pre-conditions via API (CreateUserViaApi pattern) — not UI clicks
✅ Page objects return page objects (fluent chaining)
✅ No assertions inside page object classes
✅ No shared IPage / IBrowserContext across tests

❌ Thread.Sleep / Task.Delay for waits
❌ Hardcoded credentials
❌ Test execution order dependencies
❌ Assertions inside page objects
❌ XPath with positional indexing
```

---

## 🔧 Troubleshooting

### Playwright / Browser Issues

| Problem | Cause | Solution |
|---------|-------|----------|
| `Executable doesn't exist` | Browser not installed | Run `playwright install --with-deps` |
| `Browser closed unexpectedly` | Resource exhaustion | Reduce `ParallelWorkers`; add `--disable-dev-shm-usage` |
| `TimeoutError: Locator.click` | Element not ready | Check locator; page may not have loaded fully |
| `net::ERR_NAME_NOT_RESOLVED` | Wrong BaseUrl | Verify `appsettings.{env}.json` BaseUrl value |
| WebKit tests fail on Linux | Missing dependencies | Run `playwright install webkit --with-deps` |
| Edge not found | msedge not installed | Add Edge install step (see pipeline template) |

### Configuration Issues

| Problem | Cause | Solution |
|---------|-------|----------|
| Config file not found | Wrong base path | Check `ResolveBasePath()` in ConfigurationManager |
| Credentials empty | Env vars not set | Verify `TEST_ADMIN_USER` etc. are exported |
| Wrong environment loaded | Env var not set | `echo $TEST_ENVIRONMENT` — must match overlay file name |
| `appsettings.QA.json` ignored | File not copied | Check `CopyToOutputDirectory` in `.csproj` |

### Pipeline Issues

| Problem | Cause | Solution |
|---------|-------|----------|
| `playwright install` fails | .NET build not run first | Ensure `dotnet build` runs before install step |
| TRX not published | Tests crashed before TRX written | `continueOnError: true` + check task logs |
| Secrets are empty | Variable Group not linked | Library → Pipeline permissions → Add pipeline |
| Artifacts not uploaded | Stage condition failed | Set `condition: always()` on all artifact tasks |
| Cross-browser matrix not triggered | `runAllBrowsers=false` | Queue run → set `runAllBrowsers=true` |

### Test Failures

| Problem | Cause | Solution |
|---------|-------|----------|
| Flaky test in CI only | Timing difference (headless) | Download trace → `playwright show-trace` |
| `StaleElementException` | Playwright auto-handles this | If still occurring, re-fetch locator |
| Video not recorded | `VideoOnFailure=false` | Set `true` in `appsettings.QA.json` |
| Trace not saved | `TraceOnFailure=false` | Set `true`; check `TraceDirectory` permissions |

---

<div align="center">

**Built for quality engineering teams who ship with confidence.**

*Playwright · .NET 8 · Azure DevOps · Enterprise-grade*

</div>
