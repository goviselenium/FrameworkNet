// Global usings — available across the entire project without per-file imports
global using System;
global using System.Collections.Generic;
global using System.IO;
global using System.Linq;
global using System.Text.RegularExpressions;
global using System.Threading;
global using System.Threading.Tasks;
global using NUnit.Framework;
global using Microsoft.Playwright;
global using PlaywrightFramework.Config;
global using PlaywrightFramework.Models;
global using PlaywrightFramework.Pages;
global using PlaywrightFramework.Utilities;
global using PlaywrightFramework.Utilities.Extensions;
global using PlaywrightFramework.Utilities.Helpers;
