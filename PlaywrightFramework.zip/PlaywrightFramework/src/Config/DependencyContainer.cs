using Microsoft.Extensions.DependencyInjection;
using PlaywrightFramework.Models;
using PlaywrightFramework.Utilities;
using PlaywrightFramework.Utilities.Reporting;

namespace PlaywrightFramework.Config;

/// <summary>
/// Microsoft DI composition root.
/// All framework services are registered here and resolved via
/// <see cref="Resolve{T}"/> in test base classes.
/// </summary>
public static class DependencyContainer
{
    private static IServiceProvider? _provider;
    private static readonly object   _lock = new();

    public static IServiceProvider Provider
    {
        get
        {
            if (_provider is null)
                lock (_lock)
                    _provider ??= Build();
            return _provider;
        }
    }

    private static IServiceProvider Build()
    {
        var services = new ServiceCollection();
        var settings = ConfigurationManager.Instance.Settings;

        // Settings (singleton — shared across all threads)
        services.AddSingleton(settings);
        services.AddSingleton(settings.AppSettings);
        services.AddSingleton(settings.Credentials);
        services.AddSingleton(settings.ApiSettings);

        // Core utilities (singleton — thread-safe)
        services.AddSingleton<LoggingService>();
        services.AddSingleton<ScreenshotService>();
        services.AddSingleton<ExtentReportService>();

        // Browser factory (transient — each test resolves its own)
        services.AddTransient<BrowserFactory>();

        return services.BuildServiceProvider();
    }

    public static T Resolve<T>() where T : notnull =>
        Provider.GetRequiredService<T>();
}
