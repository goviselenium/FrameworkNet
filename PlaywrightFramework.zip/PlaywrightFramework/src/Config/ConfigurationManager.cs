using Microsoft.Extensions.Configuration;
using PlaywrightFramework.Models;
using MSConfig = Microsoft.Extensions.Configuration.ConfigurationManager;

namespace PlaywrightFramework.Config;

/// <summary>
/// Singleton configuration manager.
///
/// Resolution order (last wins):
///   1. appsettings.json           — base defaults
///   2. appsettings.{ENV}.json     — environment overlay
///   3. Environment variables      — pipeline variable group / Key Vault secrets
///   4. OverrideFromEnvironment()  — explicit secret mapping for credentials
///
/// Active environment driven by TEST_ENVIRONMENT env var
/// (set as an Azure DevOps pipeline variable).
/// </summary>
public sealed class ConfigurationManager
{
    private static readonly Lazy<ConfigurationManager> _instance =
        new(() => new ConfigurationManager());

    public static ConfigurationManager Instance => _instance.Value;

    public IConfiguration   Configuration { get; }
    public FrameworkSettings Settings      { get; }

    private ConfigurationManager()
    {
        var environment = ResolveEnvironment();

        var basePath = ResolveBasePath();

        Configuration = new ConfigurationBuilder()
            .SetBasePath(basePath)
            .AddJsonFile("appsettings.json",              optional: false, reloadOnChange: false)
            .AddJsonFile($"appsettings.{environment}.json", optional: true,  reloadOnChange: false)
            .AddEnvironmentVariables()   // Pipeline vars land here via __ separator
            .Build();

        Settings = new FrameworkSettings();
        Configuration.Bind(Settings);

        // Explicit credential mapping from Key Vault–linked pipeline secrets
        OverrideCredentialsFromEnv(Settings.Credentials);
        OverrideBrowserSettingsFromEnv(Settings.AppSettings);
    }

    // ------------------------------------------------------------------ //
    //  Helpers                                                             //
    // ------------------------------------------------------------------ //

    private static string ResolveEnvironment() =>
        Environment.GetEnvironmentVariable("TEST_ENVIRONMENT")
        ?? Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")
        ?? "Dev";

    private static string ResolveBasePath()
    {
        // Works in both local (bin/Debug/net8.0) and CI (publish) layouts
        var configSubDir = Path.Combine(AppContext.BaseDirectory, "src", "Config");
        if (Directory.Exists(configSubDir)) return configSubDir;

        var configDir = Path.Combine(AppContext.BaseDirectory, "Config");
        if (Directory.Exists(configDir)) return configDir;

        return AppContext.BaseDirectory;
    }

    private static void OverrideCredentialsFromEnv(Credentials creds)
    {
        creds.AdminUser        = Env("TEST_ADMIN_USER",        creds.AdminUser);
        creds.AdminPassword    = Env("TEST_ADMIN_PASSWORD",    creds.AdminPassword);
        creds.StandardUser     = Env("TEST_STANDARD_USER",     creds.StandardUser);
        creds.StandardPassword = Env("TEST_STANDARD_PASSWORD", creds.StandardPassword);
    }

    private static void OverrideBrowserSettingsFromEnv(AppSettings app)
    {
        var browser  = Env("TEST_BROWSER",   string.Empty);
        var headless = Env("TEST_HEADLESS",  string.Empty);
        var baseUrl  = Env("TEST_BASE_URL",  string.Empty);

        if (!string.IsNullOrWhiteSpace(browser))  app.Browser  = browser;
        if (bool.TryParse(headless, out var h))    app.Headless = h;
        if (!string.IsNullOrWhiteSpace(baseUrl))   app.BaseUrl  = baseUrl;
    }

    private static string Env(string key, string fallback) =>
        Environment.GetEnvironmentVariable(key) is { Length: > 0 } v ? v : fallback;
}
