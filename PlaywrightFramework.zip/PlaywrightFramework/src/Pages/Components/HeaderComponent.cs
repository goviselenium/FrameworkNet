using Microsoft.Playwright;
using PlaywrightFramework.Models;
using PlaywrightFramework.Utilities;

namespace PlaywrightFramework.Pages.Components;

/// <summary>
/// Reusable Header component shared across multiple pages.
/// Components represent partial UI regions (header, footer, sidebar, modals)
/// that appear on many pages and deserve their own object.
/// </summary>
public sealed class HeaderComponent : BasePage
{
    private ILocator Logo          => GetByRole(AriaRole.Link, "Home").Or(GetLocator(".site-logo"));
    private ILocator SearchInput   => GetByRole(AriaRole.Searchbox, "Search");
    private ILocator SearchButton  => GetByRole(AriaRole.Button, "Search");
    private ILocator NavHome       => GetByRole(AriaRole.Link, "Home");
    private ILocator NavProducts   => GetByRole(AriaRole.Link, "Products");
    private ILocator NavAbout      => GetByRole(AriaRole.Link, "About");
    private ILocator UserMenuBtn   => GetByRole(AriaRole.Button, "My Account");
    private ILocator LogoutBtn     => GetByRole(AriaRole.Menuitem, "Logout");

    public HeaderComponent(IPage page, AppSettings settings, LoggingService log)
        : base(page, settings, log) { }

    public async Task<HeaderComponent> SearchForAsync(string query)
    {
        await FillAsync(SearchInput, query);
        await PressKeyAsync(SearchInput, "Enter");
        return this;
    }

    public async Task ClickNavHomeAsync()     => await ClickAsync(NavHome);
    public async Task ClickNavProductsAsync() => await ClickAsync(NavProducts);

    public async Task<LoginPage> ClickLogoutAsync()
    {
        await ClickAsync(UserMenuBtn);
        await ClickAsync(LogoutBtn);
        return new LoginPage(Page, Settings, Log);
    }

    public async Task<bool> IsLogoVisibleAsync() => await IsVisibleAsync(Logo);
}
