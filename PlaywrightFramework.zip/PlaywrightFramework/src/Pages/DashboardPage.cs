using Microsoft.Playwright;
using PlaywrightFramework.Models;
using PlaywrightFramework.Utilities;

namespace PlaywrightFramework.Pages;

/// <summary>Page Object for the main Dashboard / Home page.</summary>
public sealed class DashboardPage : BasePage
{
    // ------------------------------------------------------------------ //
    //  Locators                                                            //
    // ------------------------------------------------------------------ //

    private ILocator WelcomeHeading    => GetByRole(AriaRole.Heading, "Dashboard").Or(GetLocator("h1.dashboard, .welcome-header"));
    private ILocator UserMenu          => GetByRole(AriaRole.Button, "User Menu").Or(GetLocator(".user-avatar, #user-menu"));
    private ILocator LogoutOption      => GetByRole(AriaRole.Menuitem, "Logout").Or(GetLocator("a[href*='logout']"));
    private ILocator NavBar            => GetLocator("nav[aria-label='Main Navigation'], nav.main-nav");
    private ILocator LoadingSpinner    => GetLocator(".spinner, [aria-label='Loading'], .loading-overlay");
    private ILocator NotificationBell  => GetByRole(AriaRole.Button, "Notifications");

    // ------------------------------------------------------------------ //
    //  Constructor                                                         //
    // ------------------------------------------------------------------ //

    public DashboardPage(IPage page, AppSettings settings, LoggingService log)
        : base(page, settings, log) { }

    protected override string PagePath => "/dashboard";

    // ------------------------------------------------------------------ //
    //  Actions                                                             //
    // ------------------------------------------------------------------ //

    public async Task<LoginPage> LogoutAsync()
    {
        Log.Info("Logging out");
        await ClickAsync(UserMenu);
        await ClickAsync(LogoutOption);
        return new LoginPage(Page, Settings, Log);
    }

    public async Task<DashboardPage> WaitForDashboardReadyAsync()
    {
        await Wait.WaitForSpinnerToDisappearAsync();
        await Wait.WaitForVisibleAsync(WelcomeHeading);
        return this;
    }

    // ------------------------------------------------------------------ //
    //  State queries                                                       //
    // ------------------------------------------------------------------ //

    public async Task<bool>   IsUserLoggedInAsync()      => await IsVisibleAsync(UserMenu);
    public async Task<string> GetWelcomeTextAsync()      => await GetTextAsync(WelcomeHeading);
    public async Task<bool>   IsNavBarVisibleAsync()     => await IsVisibleAsync(NavBar);
    public async Task<bool>   IsNotificationBellVisible()=> await IsVisibleAsync(NotificationBell);

    // ------------------------------------------------------------------ //
    //  Page readiness                                                      //
    // ------------------------------------------------------------------ //

    public override async Task WaitForPageLoadAsync()
    {
        await base.WaitForPageLoadAsync();
        await Wait.WaitForSpinnerToDisappearAsync();
    }
}
