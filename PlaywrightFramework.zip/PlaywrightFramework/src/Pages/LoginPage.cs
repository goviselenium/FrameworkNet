using Microsoft.Playwright;
using PlaywrightFramework.Models;
using PlaywrightFramework.Utilities;

namespace PlaywrightFramework.Pages;

/// <summary>
/// Page Object for the Login page.
///
/// Playwright best practices applied:
///   - Locators use role/label/testid selectors (resilient to CSS changes)
///   - Actions return page objects for fluent chaining
///   - No assertions inside this class
///   - All interactions use Playwright's built-in auto-wait
/// </summary>
public sealed class LoginPage : BasePage
{
    // ------------------------------------------------------------------ //
    //  Locators — Playwright-idiomatic (role, label, testid preferred)    //
    // ------------------------------------------------------------------ //

    private ILocator UsernameField    => GetByLabel("Username").Or(GetByPlaceholder("Enter username"));
    private ILocator PasswordField    => GetByLabel("Password").Or(GetByPlaceholder("Enter password"));
    private ILocator LoginButton      => GetByRole(AriaRole.Button, "Sign In").Or(GetByRole(AriaRole.Button, "Login"));
    private ILocator ErrorAlert       => GetLocator("[role='alert'], .alert-danger, .error-message");
    private ILocator RememberMeCheck  => GetByLabel("Remember me");
    private ILocator ForgotPassLink   => GetByRole(AriaRole.Link, "Forgot Password?");
    private ILocator PageHeading      => GetByRole(AriaRole.Heading, "Sign In").Or(GetLocator("h1"));

    // ------------------------------------------------------------------ //
    //  Constructor                                                         //
    // ------------------------------------------------------------------ //

    public LoginPage(IPage page, AppSettings settings, LoggingService log)
        : base(page, settings, log) { }

    protected override string PagePath => "/login";

    // ------------------------------------------------------------------ //
    //  Actions                                                             //
    // ------------------------------------------------------------------ //

    public async Task<LoginPage> EnterUsernameAsync(string username)
    {
        Log.Info("Entering username: {User}", username);
        await FillAsync(UsernameField, username);
        return this;
    }

    public async Task<LoginPage> EnterPasswordAsync(string password)
    {
        Log.Info("Entering password (masked)");
        await FillAsync(PasswordField, password);
        return this;
    }

    public async Task<LoginPage> CheckRememberMeAsync()
    {
        await RememberMeCheck.CheckAsync();
        return this;
    }

    /// <summary>Clicks Login — expects success → returns DashboardPage.</summary>
    public async Task<DashboardPage> ClickLoginAsync()
    {
        Log.Info("Clicking login button");
        await ClickAsync(LoginButton);
        return new DashboardPage(Page, Settings, Log);
    }

    /// <summary>Full successful login flow.</summary>
    public async Task<DashboardPage> LoginAsAsync(string username, string password)
    {
        await EnterUsernameAsync(username);
        await EnterPasswordAsync(password);
        return await ClickLoginAsync();
    }

    /// <summary>Login expected to fail — stays on LoginPage.</summary>
    public async Task<LoginPage> LoginExpectingFailureAsync(string username, string password)
    {
        await EnterUsernameAsync(username);
        await EnterPasswordAsync(password);
        await ClickAsync(LoginButton);
        return this;
    }

    // ------------------------------------------------------------------ //
    //  State queries                                                       //
    // ------------------------------------------------------------------ //

    public async Task<bool>   IsErrorDisplayedAsync() => await IsVisibleAsync(ErrorAlert);
    public async Task<string> GetErrorMessageAsync()  => await GetTextAsync(ErrorAlert);
    public async Task<string> GetHeadingTextAsync()   => await GetTextAsync(PageHeading);
    public async Task<bool>   IsLoginButtonVisibleAsync() => await IsVisibleAsync(LoginButton);

    // ------------------------------------------------------------------ //
    //  Page readiness                                                      //
    // ------------------------------------------------------------------ //

    public override async Task WaitForPageLoadAsync()
    {
        await base.WaitForPageLoadAsync();
        await Wait.WaitForVisibleAsync(LoginButton);
    }
}
