using Microsoft.Playwright;
using PlaywrightFramework.Models;
using PlaywrightFramework.Utilities;
using PlaywrightFramework.Utilities.Extensions;
using PlaywrightFramework.Utilities.Helpers;

namespace PlaywrightFramework.Pages;

/// <summary>
/// Abstract base for all Page Object Model pages.
///
/// Provides:
///   - Playwright IPage access with action/navigation timeouts
///   - WaitHelper for explicit wait strategies
///   - LoggingService for structured test logging
///   - Typed locator builder methods (GetLocator, GetByRole, etc.)
///   - Common navigation and assertion helpers
///
/// All locators are defined as ILocator properties in derived pages.
/// No assertions live inside page objects.
/// </summary>
public abstract class BasePage
{
    protected readonly IPage         Page;
    protected readonly AppSettings   Settings;
    protected readonly LoggingService Log;
    protected readonly WaitHelper    Wait;

    protected BasePage(IPage page, AppSettings settings, LoggingService log)
    {
        Page     = page;
        Settings = settings;
        Log      = log;
        Wait     = new WaitHelper(page, settings);
    }

    // ------------------------------------------------------------------ //
    //  Navigation                                                          //
    // ------------------------------------------------------------------ //

    public virtual async Task OpenAsync(string? relativeUrl = null)
    {
        var url = string.IsNullOrWhiteSpace(relativeUrl)
            ? $"{Settings.BaseUrl}{PagePath}"
            : $"{Settings.BaseUrl}{relativeUrl}";

        Log.Info("Navigating to {Url}", url);
        await Page.GotoAsync(url, new PageGotoOptions
        {
            WaitUntil = WaitUntilState.DOMContentLoaded
        });
        await WaitForPageLoadAsync();
    }

    /// <summary>Override to specify the page's URL path segment. E.g. "/login"</summary>
    protected virtual string PagePath => string.Empty;

    public virtual Task WaitForPageLoadAsync() =>
        Page.WaitForLoadStateAsync(LoadState.NetworkIdle);

    // ------------------------------------------------------------------ //
    //  Locator builders (Playwright-idiomatic)                            //
    // ------------------------------------------------------------------ //

    protected ILocator GetLocator(string selector)          => Page.Locator(selector);
    protected ILocator GetByTestId(string testId)           => Page.GetByTestId(testId);
    protected ILocator GetByRole(AriaRole role, string name)=> Page.GetByRole(role, new PageGetByRoleOptions { Name = name });
    protected ILocator GetByLabel(string label)             => Page.GetByLabel(label);
    protected ILocator GetByPlaceholder(string placeholder) => Page.GetByPlaceholder(placeholder);
    protected ILocator GetByText(string text)               => Page.GetByText(text);
    protected ILocator GetById(string id)                   => Page.Locator($"#{id}");

    // ------------------------------------------------------------------ //
    //  Common interactions (all use Playwright auto-wait internally)      //
    // ------------------------------------------------------------------ //

    protected async Task ClickAsync(ILocator locator)
    {
        Log.Debug("Click: {Locator}", locator);
        await locator.ClickAsync();
    }

    protected async Task FillAsync(ILocator locator, string value)
    {
        Log.Debug("Fill '{Value}' into: {Locator}", value, locator);
        await locator.ClearAsync();
        await locator.FillAsync(value);
    }

    protected async Task SelectOptionAsync(ILocator locator, string value)
    {
        Log.Debug("Select '{Value}' in: {Locator}", value, locator);
        await locator.SelectOptionAsync(value);
    }

    protected async Task<string> GetTextAsync(ILocator locator) =>
        await locator.InnerTextAsync();

    protected async Task<bool> IsVisibleAsync(ILocator locator) =>
        await locator.IsVisibleAsync();

    protected async Task<bool> IsEnabledAsync(ILocator locator) =>
        await locator.IsEnabledAsync();

    protected async Task<string?> GetAttributeAsync(ILocator locator, string attribute) =>
        await locator.GetAttributeAsync(attribute);

    protected async Task HoverAsync(ILocator locator) =>
        await locator.HoverAsync();

    protected async Task PressKeyAsync(ILocator locator, string key) =>
        await locator.PressAsync(key);

    protected async Task ScrollIntoViewAsync(ILocator locator) =>
        await locator.ScrollIntoViewIfNeededAsync();

    // ------------------------------------------------------------------ //
    //  Page state queries                                                  //
    // ------------------------------------------------------------------ //

    public string CurrentUrl                  => Page.Url;
    public async Task<string> GetTitleAsync() => await Page.TitleAsync();

    public bool UrlContains(string fragment) =>
        Page.Url.Contains(fragment, StringComparison.OrdinalIgnoreCase);
}
