using Microsoft.Playwright;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using PlaywrightFramework.Config;
using PlaywrightFramework.Models;
using PlaywrightFramework.Utilities;
using PlaywrightFramework.Utilities.Reporting;

namespace PlaywrightFramework.Tests.Base;

/// <summary>
/// Abstract base for all NUnit test classes.
///
/// Playwright lifecycle per fixture:
///   [OneTimeSetUp]    → Playwright.CreateAsync() + Browser (shared per fixture)
///   [SetUp]           → New BrowserContext + Page (isolated per test)
///   [TearDown]        → Screenshot/video/trace on failure + Context dispose
///   [OneTimeTearDown] → Browser + Playwright dispose + Report flush
///
/// Thread-safety:
///   Each parallel fixture runs on its own thread.
///   IPlaywright, IBrowser are created once per fixture (thread-safe).
///   IBrowserContext and IPage are per-test (fully isolated).
/// </summary>
[TestFixture]
public abstract class BaseTest
{
    // ── Fixture-scoped (shared within a fixture, one per thread) ─────────
    protected IPlaywright Playwright  { get; private set; } = null!;
    protected IBrowser    Browser     { get; private set; } = null!;

    // ── Test-scoped (fresh per test) ────────────────────────────────────
    protected IBrowserContext Context  { get; private set; } = null!;
    protected IPage           Page     { get; private set; } = null!;
    protected ApiClient       Api      { get; private set; } = null!;

    // ── DI-resolved services ─────────────────────────────────────────────
    protected AppSettings         Settings    { get; private set; } = null!;
    protected Credentials         Credentials { get; private set; } = null!;
    protected LoggingService      Log         { get; private set; } = null!;
    protected ScreenshotService   Screenshots { get; private set; } = null!;
    protected TraceService        Tracer      { get; private set; } = null!;
    protected ExtentReportService Report      { get; private set; } = null!;

    private BrowserFactory _factory = null!;

    // ================================================================== //
    //  Fixture-level setup (once per TestFixture class)                   //
    // ================================================================== //

    [OneTimeSetUp]
    public virtual async Task OneTimeSetUpAsync()
    {
        // Resolve services from DI
        Settings    = DependencyContainer.Resolve<AppSettings>();
        Credentials = DependencyContainer.Resolve<Credentials>();
        Log         = DependencyContainer.Resolve<LoggingService>();
        Screenshots = DependencyContainer.Resolve<ScreenshotService>();
        Report      = DependencyContainer.Resolve<ExtentReportService>();
        _factory    = DependencyContainer.Resolve<BrowserFactory>();
        Tracer      = new TraceService(Settings, Log);

        Log.Info("=== Suite STARTED: {Suite} | Env: {Env} | Browser: {Browser} ===",
            GetType().Name, Settings.Environment, Settings.Browser);

        // Create Playwright + Browser once per fixture
        Playwright = await Microsoft.Playwright.Playwright.CreateAsync();
        Browser    = await _factory.CreateBrowserAsync(Playwright);
    }

    // ================================================================== //
    //  Per-test setup                                                      //
    // ================================================================== //

    [SetUp]
    public virtual async Task SetUpAsync()
    {
        var testName = TestContext.CurrentContext.Test.FullName;
        Log.Info("--- Test STARTED: {Test} ---", testName);

        // Determine if tracing should be active (always on retry)
        var traceOnRetry = TestContext.CurrentContext.Test.Properties
            .ContainsKey("TraceOnRetry");
        var enableTrace = Settings.TraceOnFailure || traceOnRetry;

        // Fresh isolated context per test
        Context = await _factory.CreateContextAsync(
            Browser,
            enableVideo : Settings.VideoOnFailure,
            enableTrace : enableTrace);

        Page = await Context.NewPageAsync();

        // Wire up Playwright API request context
        var apiContext = await Playwright.APIRequest.NewContextAsync(
            new APIRequestNewContextOptions
            {
                BaseURL       = Settings.ApiBaseUrl,
                Timeout       = Settings.ApiSettings().ApiTimeoutMs,
                IgnoreHTTPSErrors = Settings.IgnoreHTTPSErrors,
                ExtraHTTPHeaders  = Settings.ApiSettings().DefaultHeaders
            });
        Api = new ApiClient(apiContext, DependencyContainer.Resolve<ApiSettings>(), Log);

        // Start Extent test node
        Report.CreateTest(testName, TestContext.CurrentContext.Test.MethodName);
        Report.LogInfo($"Browser: {Settings.Browser} | Env: {Settings.Environment}");
        Report.LogInfo($"URL: {Settings.BaseUrl}");

        // Navigate to base URL
        await Page.GotoAsync(Settings.BaseUrl,
            new PageGotoOptions { WaitUntil = WaitUntilState.DOMContentLoaded });
    }

    // ================================================================== //
    //  Per-test teardown                                                   //
    // ================================================================== //

    [TearDown]
    public virtual async Task TearDownAsync()
    {
        var result   = TestContext.CurrentContext.Result;
        var testName = TestContext.CurrentContext.Test.FullName;
        var failed   = result.Outcome.Status == TestStatus.Failed;

        try
        {
            if (failed)
            {
                Log.Warn("Test FAILED: {Test} — {Message}", testName, result.Message);
                Report.LogFail($"FAILED: {result.Message}");

                // 1. Screenshot
                var screenshotPath = await Screenshots.CaptureAsync(Page, testName);
                if (screenshotPath is not null)
                {
                    TestContext.AddTestAttachment(screenshotPath, "Failure Screenshot");
                    Report.AttachScreenshot(screenshotPath);
                }

                // 2. Trace
                var tracePath = await Tracer.StopAndSaveAsync(Context, testName);
                if (tracePath is not null)
                {
                    TestContext.AddTestAttachment(tracePath, "Playwright Trace");
                    Report.AttachTrace(tracePath);
                }

                // 3. Video (Playwright saves video on context close)
                // Video path is only available after context is closed (below)
            }
            else
            {
                Log.Info("Test PASSED: {Test}", testName);
                Report.LogPass("Test passed ✓");

                // Stop tracing without saving (not needed for passed tests)
                if (Settings.TraceOnFailure)
                    await Context.Tracing.StopAsync();
            }
        }
        finally
        {
            // Always close context — this finalises video recording
            await Context.CloseAsync();

            // Attach video if recording was enabled and test failed
            if (failed && Settings.VideoOnFailure)
            {
                var videoPath = Page.Video?.PathAsync().Result;
                if (videoPath is not null && File.Exists(videoPath))
                {
                    TestContext.AddTestAttachment(videoPath, "Test Video");
                    Report.AttachVideo(videoPath);
                }
            }

            await Context.DisposeAsync();
            Log.Info("--- Test FINISHED: {Test} ---", testName);
        }
    }

    // ================================================================== //
    //  Fixture-level teardown                                             //
    // ================================================================== //

    [OneTimeTearDown]
    public virtual async Task OneTimeTearDownAsync()
    {
        Report.Flush();
        await Browser.CloseAsync();
        Playwright.Dispose();
        Log.Info("=== Suite FINISHED: {Suite} ===", GetType().Name);
    }
}

// ── Extension to resolve ApiSettings cleanly ───────────────────────────
file static class AppSettingsExtensions
{
    public static ApiSettings ApiSettings(this AppSettings _) =>
        DependencyContainer.Resolve<ApiSettings>();
}
