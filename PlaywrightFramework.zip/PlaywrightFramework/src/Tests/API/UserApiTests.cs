using System.Text.Json;
using FluentAssertions;
using NUnit.Framework;
using PlaywrightFramework.Tests.Base;
using PlaywrightFramework.Utilities.Helpers;

namespace PlaywrightFramework.Tests.API;

/// <summary>
/// API tests using Playwright's built-in IAPIRequestContext.
/// These run without a visible browser — pure REST validation.
///
/// Hybrid pattern: Create test data via API, verify result in the UI.
/// </summary>
[TestFixture]
[Category("API")]
[Parallelizable(ParallelScope.Self)]
public sealed class UserApiTests : BaseTest
{
    private string _authToken = string.Empty;

    [SetUp]
    public override async Task SetUpAsync()
    {
        await base.SetUpAsync();

        // Obtain auth token for subsequent API calls
        _authToken = await Api.GetBearerTokenAsync(
            "/api/auth/login",
            Credentials.AdminUser.Length > 0 ? Credentials.AdminUser : "admin@example.com",
            Credentials.AdminPassword.Length > 0 ? Credentials.AdminPassword : "Admin@12345")
            ?? string.Empty;

        if (!string.IsNullOrWhiteSpace(_authToken))
            Report.LogInfo("Bearer token acquired successfully");
    }

    // ── TC-API-001 ─────────────────────────────────────────────────────────
    [Test, RetryOnFailure]
    [Description("GET /api/users returns HTTP 200 with a non-empty user list")]
    public async Task GetUsers_ShouldReturn200WithData()
    {
        // Act
        var response = await Api.GetAsync<JsonElement>("/api/users",
            headers: new() { ["Authorization"] = $"Bearer {_authToken}" });

        // Assert
        response.IsSuccess.Should().BeTrue(
            because: $"GET /api/users should return 2xx, got {response.StatusCode}");

        response.StatusCode.Should().Be(200);

        Report.LogPass($"GET /api/users → {response.StatusCode} ✓");
    }

    // ── TC-API-002 ─────────────────────────────────────────────────────────
    [Test, RetryOnFailure]
    [Description("POST /api/users creates a new user and returns 201")]
    public async Task CreateUser_ShouldReturn201WithCreatedUser()
    {
        // Arrange — generate unique test data
        var faker    = new Bogus.Faker();
        var newUser  = new
        {
            name     = faker.Name.FullName(),
            email    = faker.Internet.Email(),
            role     = "viewer"
        };

        // Act
        var response = await Api.PostAsync<JsonElement>("/api/users", newUser,
            headers: new() { ["Authorization"] = $"Bearer {_authToken}" });

        // Assert
        response.IsSuccess.Should().BeTrue(
            because: $"POST /api/users should return 2xx, got {response.StatusCode}");

        response.StatusCode.Should().Be(201);

        response.Data.TryGetProperty("id", out var id).Should().BeTrue(
            because: "created user response must contain an id field");

        id.GetInt32().Should().BeGreaterThan(0,
            because: "the assigned user id must be a positive integer");

        Report.LogPass($"POST /api/users → {response.StatusCode} | id={id} ✓");
    }

    // ── TC-API-003 ─────────────────────────────────────────────────────────
    [Test]
    [Description("GET /api/users/{id} returns 404 for a non-existent user")]
    public async Task GetUser_WithInvalidId_ShouldReturn404()
    {
        // Act
        var response = await Api.GetAsync<JsonElement>("/api/users/999999",
            headers: new() { ["Authorization"] = $"Bearer {_authToken}" });

        // Assert
        response.StatusCode.Should().Be(404,
            because: "a non-existent resource should return HTTP 404");

        Report.LogPass("GET /api/users/999999 → 404 ✓");
    }

    // ── TC-API-004 : Hybrid API + UI test ─────────────────────────────────
    [Test, RetryOnFailure]
    [Description("Create a user via API then verify they appear in the admin UI")]
    public async Task CreateUserViaApi_ShouldAppearInAdminUi()
    {
        // Step 1 — Create user via API (fast, reliable setup)
        var faker   = new Bogus.Faker();
        var email   = faker.Internet.Email();
        var payload = new { name = faker.Name.FullName(), email, role = "viewer" };

        var createResponse = await Api.PostAsync<JsonElement>("/api/users", payload,
            headers: new() { ["Authorization"] = $"Bearer {_authToken}" });

        createResponse.IsSuccess.Should().BeTrue(
            because: "API user creation must succeed before UI verification");

        Report.LogInfo($"User created via API: {email}");

        // Step 2 — Verify in the UI
        await Page.GotoAsync($"{Settings.BaseUrl}/admin/users");
        var userRow = Page.GetByText(email);

        (await userRow.IsVisibleAsync()).Should().BeTrue(
            because: "newly created user should appear in the admin users list");

        Report.LogPass("API-created user is visible in admin UI ✓");
    }
}
