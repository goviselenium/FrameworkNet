using FluentAssertions;
using NUnit.Framework;
using PlaywrightFramework.Pages;
using PlaywrightFramework.Tests.Base;
using PlaywrightFramework.Utilities.Helpers;

namespace PlaywrightFramework.Tests.Regression;

/// <summary>
/// Regression tests for the Dashboard.
/// Run on nightly scheduled pipeline and release triggers.
/// </summary>
[TestFixture]
[Category("Regression")]
[Category("Dashboard")]
[Parallelizable(ParallelScope.Self)]
public sealed class DashboardRegressionTests : BaseTest
{
    private DashboardPage _dashboard = null!;

    [SetUp]
    public override async Task SetUpAsync()
    {
        await base.SetUpAsync();

        // Pre-condition: authenticated user
        var loginPage = new LoginPage(Page, Settings, Log);
        await loginPage.OpenAsync();

        _dashboard = await loginPage.LoginAsAsync(
            Credentials.StandardUser.Length > 0
                ? Credentials.StandardUser : "testuser@example.com",
            Credentials.StandardPassword.Length > 0
                ? Credentials.StandardPassword : "Test@12345");

        await _dashboard.WaitForDashboardReadyAsync();
    }

    // ── TC-DASH-001 ────────────────────────────────────────────────────────
    [Test, RetryOnFailure]
    [Description("Verify dashboard loads with welcome message after login")]
    public async Task Dashboard_AfterLogin_ShouldDisplayWelcomeMessage()
    {
        var welcome = await _dashboard.GetWelcomeTextAsync();

        welcome.Should().NotBeNullOrWhiteSpace(
            because: "a personalised welcome message must appear post-login");

        (await _dashboard.IsUserLoggedInAsync()).Should().BeTrue(
            because: "user menu must be visible confirming authenticated session");

        Report.LogPass("Dashboard welcome message visible ✓");
    }

    // ── TC-DASH-002 ────────────────────────────────────────────────────────
    [Test]
    [Description("Verify the main navigation bar is present on the dashboard")]
    public async Task Dashboard_AfterLogin_ShouldShowNavBar()
    {
        (await _dashboard.IsNavBarVisibleAsync()).Should().BeTrue(
            because: "main navigation must be rendered for authenticated users");

        Report.LogPass("Navigation bar is visible on dashboard ✓");
    }

    // ── TC-DASH-003 ────────────────────────────────────────────────────────
    [Test, RetryOnFailure]
    [Description("Verify logout redirects user to the login page")]
    public async Task Dashboard_Logout_ShouldRedirectToLoginPage()
    {
        // Act
        var loginPage = await _dashboard.LogoutAsync();

        // Assert
        Page.UrlContains("login").Should().BeTrue(
            because: "logout must redirect back to the login page");

        (await loginPage.IsLoginButtonVisibleAsync()).Should().BeTrue(
            because: "login CTA must be visible after logout");

        Report.LogPass("Logout redirects to login page ✓");
    }
}
