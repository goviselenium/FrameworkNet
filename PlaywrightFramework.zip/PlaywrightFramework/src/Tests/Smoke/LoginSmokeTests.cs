using FluentAssertions;
using NUnit.Framework;
using PlaywrightFramework.Pages;
using PlaywrightFramework.Tests.Base;
using PlaywrightFramework.Utilities.Helpers;

namespace PlaywrightFramework.Tests.Smoke;

/// <summary>
/// Smoke tests for the Authentication flow.
/// Run on every pipeline trigger (PR, push to main).
/// </summary>
[TestFixture]
[Category("Smoke")]
[Category("Authentication")]
[Parallelizable(ParallelScope.Self)]
public sealed class LoginSmokeTests : BaseTest
{
    private LoginPage _loginPage = null!;

    [SetUp]
    public override async Task SetUpAsync()
    {
        await base.SetUpAsync();
        _loginPage = new LoginPage(Page, Settings, Log);
        await _loginPage.OpenAsync();
    }

    // ── TC-AUTH-001 ────────────────────────────────────────────────────────
    [Test, RetryOnFailure]
    [Description("Verify valid credentials redirect to the dashboard")]
    public async Task Login_WithValidCredentials_ShouldRedirectToDashboard()
    {
        // Arrange
        var user = Credentials.StandardUser.Length > 0
            ? Credentials.StandardUser : "testuser@example.com";
        var pass = Credentials.StandardPassword.Length > 0
            ? Credentials.StandardPassword : "Test@12345";

        // Act
        var dashboard = await _loginPage.LoginAsAsync(user, pass);
        await dashboard.WaitForDashboardReadyAsync();

        // Assert
        (await dashboard.IsUserLoggedInAsync()).Should().BeTrue(
            because: "authenticated user must see the user menu on dashboard");

        Page.UrlContains("dashboard").Should().BeTrue(
            because: "successful login should redirect to /dashboard");

        Report.LogPass("Valid credentials redirect to dashboard ✓");
    }

    // ── TC-AUTH-002 ────────────────────────────────────────────────────────
    [Test, RetryOnFailure]
    [Description("Verify invalid password shows an error message")]
    public async Task Login_WithInvalidPassword_ShouldShowErrorMessage()
    {
        // Act
        await _loginPage.LoginExpectingFailureAsync("user@example.com", "WrongPassword!");

        // Assert
        (await _loginPage.IsErrorDisplayedAsync()).Should().BeTrue(
            because: "wrong credentials must surface an error alert");

        var errorMsg = await _loginPage.GetErrorMessageAsync();
        errorMsg.Should().NotBeNullOrWhiteSpace(
            because: "the error must contain user-readable guidance");

        Report.LogPass("Invalid password shows error message ✓");
    }

    // ── TC-AUTH-003 ────────────────────────────────────────────────────────
    [Test]
    [Description("Verify submitting blank credentials shows validation")]
    public async Task Login_WithEmptyCredentials_ShouldShowValidation()
    {
        // Act
        await _loginPage.LoginExpectingFailureAsync(string.Empty, string.Empty);

        // Assert
        (await _loginPage.IsErrorDisplayedAsync()).Should().BeTrue(
            because: "empty submission must trigger form validation");

        Report.LogPass("Empty credentials trigger validation ✓");
    }

    // ── TC-AUTH-004 ────────────────────────────────────────────────────────
    [Test]
    [Description("Verify the login page title and heading are correct")]
    public async Task LoginPage_ShouldHaveCorrectTitleAndHeading()
    {
        // Assert
        var title = await _loginPage.GetTitleAsync();
        title.Should().NotBeNullOrWhiteSpace(because: "page must have a document title");

        (await _loginPage.IsLoginButtonVisibleAsync()).Should().BeTrue(
            because: "login CTA must be visible on page load");

        Report.LogPass("Login page title and heading verified ✓");
    }
}
