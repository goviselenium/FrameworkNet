using NUnit.Framework;

// ── Parallel execution ──────────────────────────────────────────────────────
// Each [TestFixture] class runs in its own thread.
// Tests within a fixture are serialised by default.
// Add [Parallelizable(ParallelScope.Self)] to a fixture to parallelise its tests.
// Override worker count at runtime: dotnet test -- NUnit.NumberOfTestWorkers=8

[assembly: Parallelizable(ParallelScope.Fixtures)]
[assembly: LevelOfParallelism(4)]
