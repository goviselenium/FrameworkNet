using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Reporter.Config;
using PlaywrightFramework.Models;

namespace PlaywrightFramework.Utilities.Reporting;

/// <summary>
/// Thread-safe Extent Reports HTML report service.
/// One HTML report per test run. Each parallel test thread
/// gets its own ExtentTest node via ThreadLocal.
/// </summary>
public sealed class ExtentReportService : IDisposable
{
    private readonly ExtentReports              _extent;
    private readonly ThreadLocal<ExtentTest>    _currentTest = new();
    private readonly string                     _reportPath;

    public ExtentReportService(AppSettings settings)
    {
        var reportDir = Path.GetFullPath(settings.ReportDirectory);
        Directory.CreateDirectory(reportDir);

        var timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        _reportPath   = Path.Combine(reportDir, $"TestReport_{settings.Environment}_{timestamp}.html");

        var reporter = new ExtentSparkReporter(_reportPath);
        reporter.Config.Theme         = Theme.Dark;
        reporter.Config.DocumentTitle = $"Playwright Test Report — {settings.Environment}";
        reporter.Config.ReportName    = $"Test Execution | {settings.Environment} | {settings.Browser}";
        reporter.Config.Encoding      = "UTF-8";

        _extent = new ExtentReports();
        _extent.AttachReporter(reporter);
        _extent.AddSystemInfo("Environment",  settings.Environment);
        _extent.AddSystemInfo("Browser",      settings.Browser);
        _extent.AddSystemInfo("Headless",     settings.Headless.ToString());
        _extent.AddSystemInfo("Base URL",     settings.BaseUrl);
        _extent.AddSystemInfo("OS",           Environment.OSVersion.ToString());
        _extent.AddSystemInfo("Machine",      Environment.MachineName);
        _extent.AddSystemInfo("Executed By",  Environment.UserName);
        _extent.AddSystemInfo("Executed At",  DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
    }

    // ------------------------------------------------------------------ //
    //  Test lifecycle                                                      //
    // ------------------------------------------------------------------ //

    public ExtentTest CreateTest(string name, string? description = null)
    {
        var test = _extent.CreateTest(name, description);
        _currentTest.Value = test;
        return test;
    }

    public ExtentTest? CurrentTest => _currentTest.Value;

    // ------------------------------------------------------------------ //
    //  Logging                                                             //
    // ------------------------------------------------------------------ //

    public void LogPass(string message)    => _currentTest.Value?.Pass(message);
    public void LogFail(string message)    => _currentTest.Value?.Fail(message);
    public void LogInfo(string message)    => _currentTest.Value?.Info(message);
    public void LogWarning(string message) => _currentTest.Value?.Warning(message);
    public void LogSkip(string message)    => _currentTest.Value?.Skip(message);

    public void LogFailWithException(Exception ex) =>
        _currentTest.Value?.Fail(ex);

    // ------------------------------------------------------------------ //
    //  Media attachments                                                   //
    // ------------------------------------------------------------------ //

    public void AttachScreenshot(string screenshotPath)
    {
        if (_currentTest.Value is not null && File.Exists(screenshotPath))
            _currentTest.Value.AddScreenCaptureFromPath(screenshotPath, "Failure Screenshot");
    }

    public void AttachTrace(string tracePath)
    {
        if (_currentTest.Value is not null && File.Exists(tracePath))
            _currentTest.Value.Info($"Playwright Trace: <a href='{tracePath}'>{Path.GetFileName(tracePath)}</a>");
    }

    public void AttachVideo(string videoPath)
    {
        if (_currentTest.Value is not null && File.Exists(videoPath))
            _currentTest.Value.Info($"Test Video: <a href='{videoPath}'>{Path.GetFileName(videoPath)}</a>");
    }

    // ------------------------------------------------------------------ //
    //  Finalise                                                            //
    // ------------------------------------------------------------------ //

    public void Flush() => _extent.Flush();

    public void Dispose()
    {
        _extent.Flush();
        _currentTest.Dispose();
    }
}
