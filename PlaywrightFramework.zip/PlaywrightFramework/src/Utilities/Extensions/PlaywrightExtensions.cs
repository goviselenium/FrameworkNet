using Microsoft.Playwright;

namespace PlaywrightFramework.Utilities.Extensions;

/// <summary>Extension methods for IPage and ILocator.</summary>
public static class PlaywrightExtensions
{
    // ------------------------------------------------------------------ //
    //  IPage extensions                                                    //
    // ------------------------------------------------------------------ //

    public static async Task NavigateAndWaitAsync(this IPage page, string url)
    {
        await page.GotoAsync(url, new PageGotoOptions
        {
            WaitUntil = WaitUntilState.NetworkIdle
        });
    }

    public static async Task<string> GetTitleAsync(this IPage page) =>
        await page.TitleAsync();

    public static async Task<string> GetCurrentUrlAsync(this IPage page) =>
        page.Url;

    public static async Task ScrollToBottomAsync(this IPage page) =>
        await page.EvaluateAsync("window.scrollTo(0, document.body.scrollHeight)");

    public static async Task ScrollToTopAsync(this IPage page) =>
        await page.EvaluateAsync("window.scrollTo(0, 0)");

    public static async Task WaitForNetworkIdleAsync(this IPage page, int timeoutMs = 30_000) =>
        await page.WaitForLoadStateAsync(LoadState.NetworkIdle,
            new PageWaitForLoadStateOptions { Timeout = timeoutMs });

    public static bool UrlContains(this IPage page, string fragment) =>
        page.Url.Contains(fragment, StringComparison.OrdinalIgnoreCase);

    // ------------------------------------------------------------------ //
    //  ILocator extensions                                                 //
    // ------------------------------------------------------------------ //

    public static async Task ClearAndTypeAsync(this ILocator locator, string text)
    {
        await locator.ClearAsync();
        await locator.FillAsync(text);
    }

    public static async Task ScrollIntoViewAsync(this ILocator locator) =>
        await locator.ScrollIntoViewIfNeededAsync();

    public static async Task<bool> IsVisibleSafeAsync(this ILocator locator)
    {
        try { return await locator.IsVisibleAsync(); }
        catch { return false; }
    }

    public static async Task<bool> IsEnabledSafeAsync(this ILocator locator)
    {
        try { return await locator.IsEnabledAsync(); }
        catch { return false; }
    }

    public static async Task<string> GetTextSafeAsync(this ILocator locator)
    {
        try { return await locator.InnerTextAsync(); }
        catch { return string.Empty; }
    }

    public static async Task SelectByLabelAsync(this ILocator locator, string label) =>
        await locator.SelectOptionAsync(new SelectOptionValue { Label = label });

    public static async Task SelectByValueAsync(this ILocator locator, string value) =>
        await locator.SelectOptionAsync(new SelectOptionValue { Value = value });

    public static async Task HoverAndClickAsync(this ILocator locator)
    {
        await locator.HoverAsync();
        await locator.ClickAsync();
    }

    public static async Task ClickWithRetryAsync(this ILocator locator, int maxAttempts = 3)
    {
        for (int i = 0; i < maxAttempts; i++)
        {
            try
            {
                await locator.ClickAsync();
                return;
            }
            catch when (i < maxAttempts - 1)
            {
                await Task.Delay(500);
            }
        }
    }
}
