using NUnit.Framework;
using NUnit.Framework.Interfaces;
using NUnit.Framework.Internal;
using NUnit.Framework.Internal.Commands;
using PlaywrightFramework.Config;
using PlaywrightFramework.Models;

namespace PlaywrightFramework.Utilities.Helpers;

/// <summary>
/// NUnit retry attribute. Retries a failing test up to MaxRetryCount times.
/// On the second attempt onward, Playwright tracing is activated automatically
/// via the TraceOnRetry signal on the test thread.
///
/// Usage:
///   [Test, RetryOnFailure]       ← uses appsettings MaxRetryCount
///   [Test, RetryOnFailure(3)]    ← explicit override
/// </summary>
[AttributeUsage(AttributeTargets.Method)]
public sealed class RetryOnFailureAttribute : NUnitAttribute, IRepeatTest
{
    private readonly int _count;

    public RetryOnFailureAttribute()
        => _count = DependencyContainer.Resolve<AppSettings>().MaxRetryCount;

    public RetryOnFailureAttribute(int count) => _count = count;

    public TestCommand Wrap(TestCommand command) => new RetryCommand(command, _count);

    // ------------------------------------------------------------------ //

    private sealed class RetryCommand : DelegatingTestCommand
    {
        private readonly int _maxRetries;

        public RetryCommand(TestCommand inner, int maxRetries)
            : base(inner) => _maxRetries = maxRetries;

        public override TestResult Execute(TestExecutionContext context)
        {
            var log = DependencyContainer.Resolve<LoggingService>();
            int attempt = 0;

            while (attempt <= _maxRetries)
            {
                // Signal BaseTest to enable tracing on retry attempts
                if (attempt > 0)
                    TestContext.CurrentContext.Test.Properties.Set("TraceOnRetry", true);

                try
                {
                    context.CurrentResult = innerCommand.Execute(context);
                    if (context.CurrentResult.ResultState != ResultState.Failure &&
                        context.CurrentResult.ResultState != ResultState.Error)
                        break;
                }
                catch (Exception ex) when (attempt < _maxRetries)
                {
                    context.CurrentResult = context.CurrentTest.MakeTestResult();
                    context.CurrentResult.RecordException(ex);
                }

                if (attempt < _maxRetries)
                {
                    log.Warn("Test '{Name}' failed — attempt {Attempt}/{Max}. Retrying...",
                        context.CurrentTest.Name, attempt + 1, _maxRetries + 1);
                }

                attempt++;
            }

            return context.CurrentResult;
        }
    }
}
