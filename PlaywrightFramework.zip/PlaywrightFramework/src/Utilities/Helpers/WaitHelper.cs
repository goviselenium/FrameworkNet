using Microsoft.Playwright;
using PlaywrightFramework.Models;

namespace PlaywrightFramework.Utilities.Helpers;

/// <summary>
/// Playwright-native wait helpers.
/// Playwright auto-waits on most actions — this helper covers
/// scenarios that need explicit custom conditions.
/// Never uses Thread.Sleep.
/// </summary>
public sealed class WaitHelper
{
    private readonly IPage       _page;
    private readonly AppSettings _settings;

    public WaitHelper(IPage page, AppSettings settings)
    {
        _page     = page;
        _settings = settings;
    }

    // ------------------------------------------------------------------ //
    //  Network / Load state                                               //
    // ------------------------------------------------------------------ //

    public async Task WaitForNetworkIdleAsync(int? timeoutMs = null) =>
        await _page.WaitForLoadStateAsync(LoadState.NetworkIdle,
            new PageWaitForLoadStateOptions
            {
                Timeout = timeoutMs ?? _settings.NavigationTimeoutMs
            });

    public async Task WaitForDOMLoadedAsync(int? timeoutMs = null) =>
        await _page.WaitForLoadStateAsync(LoadState.DOMContentLoaded,
            new PageWaitForLoadStateOptions
            {
                Timeout = timeoutMs ?? _settings.DefaultTimeoutMs
            });

    // ------------------------------------------------------------------ //
    //  URL / navigation                                                    //
    // ------------------------------------------------------------------ //

    public async Task WaitForUrlContainsAsync(string fragment, int? timeoutMs = null) =>
        await _page.WaitForURLAsync(
            new Regex(Regex.Escape(fragment)),
            new PageWaitForURLOptions { Timeout = timeoutMs ?? _settings.NavigationTimeoutMs });

    public async Task WaitForUrlAsync(string url, int? timeoutMs = null) =>
        await _page.WaitForURLAsync(url,
            new PageWaitForURLOptions { Timeout = timeoutMs ?? _settings.NavigationTimeoutMs });

    // ------------------------------------------------------------------ //
    //  Element conditions                                                  //
    // ------------------------------------------------------------------ //

    public async Task WaitForVisibleAsync(ILocator locator, int? timeoutMs = null) =>
        await locator.WaitForAsync(new LocatorWaitForOptions
        {
            State   = WaitForSelectorState.Visible,
            Timeout = timeoutMs ?? _settings.DefaultTimeoutMs
        });

    public async Task WaitForHiddenAsync(ILocator locator, int? timeoutMs = null) =>
        await locator.WaitForAsync(new LocatorWaitForOptions
        {
            State   = WaitForSelectorState.Hidden,
            Timeout = timeoutMs ?? _settings.DefaultTimeoutMs
        });

    public async Task WaitForEnabledAsync(ILocator locator, int? timeoutMs = null) =>
        await locator.WaitForAsync(new LocatorWaitForOptions
        {
            State   = WaitForSelectorState.Visible,
            Timeout = timeoutMs ?? _settings.DefaultTimeoutMs
        });

    // ------------------------------------------------------------------ //
    //  Custom JS condition                                                 //
    // ------------------------------------------------------------------ //

    public async Task<T?> WaitForConditionAsync<T>(
        string jsExpression, int? timeoutMs = null) =>
        await _page.WaitForFunctionAsync(jsExpression,
            null,
            new PageWaitForFunctionOptions
            {
                Timeout = timeoutMs ?? _settings.DefaultTimeoutMs,
                PollingInterval = 500
            }) is { } handle
            ? await handle.JsonValueAsync<T>()
            : default;

    // ------------------------------------------------------------------ //
    //  Spinners / overlays                                                 //
    // ------------------------------------------------------------------ //

    public async Task WaitForSpinnerToDisappearAsync(
        string spinnerSelector = ".spinner, .loading-overlay",
        int? timeoutMs = null)
    {
        try
        {
            var spinner = _page.Locator(spinnerSelector);
            // Only wait if spinner is actually present
            if (await spinner.IsVisibleAsync())
                await WaitForHiddenAsync(spinner, timeoutMs);
        }
        catch
        {
            // Spinner never appeared — proceed
        }
    }

    // ------------------------------------------------------------------ //
    //  Response / API waits                                               //
    // ------------------------------------------------------------------ //

    public async Task<IResponse> WaitForApiResponseAsync(
        string urlPattern, int? timeoutMs = null) =>
        await _page.WaitForResponseAsync(urlPattern,
            new PageWaitForResponseOptions
            {
                Timeout = timeoutMs ?? _settings.DefaultTimeoutMs
            });
}
