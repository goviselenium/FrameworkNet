using Serilog;
using Serilog.Events;
using PlaywrightFramework.Models;

namespace PlaywrightFramework.Utilities;

/// <summary>
/// Centralised Serilog logging service.
/// Writes to Console (real-time in Azure DevOps task logs)
/// and a daily rolling file in TestResults/Logs/.
/// </summary>
public sealed class LoggingService : IDisposable
{
    public ILogger Logger { get; }

    public LoggingService(AppSettings settings)
    {
        var logDir  = Path.GetFullPath(settings.LogDirectory);
        Directory.CreateDirectory(logDir);

        var logFile = Path.Combine(logDir, "playwright-.log");

        Logger = new LoggerConfiguration()
            .MinimumLevel.Debug()
            .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
            .Enrich.WithThreadId()
            .Enrich.WithProperty("Environment", settings.Environment)
            .Enrich.WithProperty("Browser",     settings.Browser)
            .WriteTo.Console(
                outputTemplate:
                "[{Timestamp:HH:mm:ss} {Level:u3}] [T{ThreadId}] {Message:lj}{NewLine}{Exception}")
            .WriteTo.File(
                logFile,
                rollingInterval:        RollingInterval.Day,
                retainedFileCountLimit: 7,
                outputTemplate:
                "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] [T{ThreadId}] [{Environment}|{Browser}] {Message:lj}{NewLine}{Exception}")
            .CreateLogger();

        Serilog.Log.Logger = Logger;
    }

    public void Info(string msg, params object[] args)    => Logger.Information(msg, args);
    public void Warn(string msg, params object[] args)    => Logger.Warning(msg, args);
    public void Error(string msg, params object[] args)   => Logger.Error(msg, args);
    public void Error(Exception ex, string msg)           => Logger.Error(ex, msg);
    public void Debug(string msg, params object[] args)   => Logger.Debug(msg, args);

    public void Dispose() => Serilog.Log.CloseAndFlush();
}
