using System.Text.Json;
using Microsoft.Playwright;
using PlaywrightFramework.Models;

namespace PlaywrightFramework.Utilities;

/// <summary>
/// Typed REST API client built on Playwright's IAPIRequestContext.
///
/// Advantages over standalone HttpClient:
///   - Shares the same browser session (cookies, auth tokens) automatically
///   - Built into Playwright — no extra dependencies
///   - Supports the same routing and network interception as the browser
///
/// Usage:
///   var client  = new ApiClient(apiContext, settings, log);
///   var product = await client.GetAsync&lt;ProductDto&gt;("/api/products/1");
///   product.IsSuccess.Should().BeTrue();
///   product.Data!.Name.Should().Be("Widget");
/// </summary>
public sealed class ApiClient
{
    private readonly IAPIRequestContext _context;
    private readonly ApiSettings        _apiSettings;
    private readonly LoggingService     _log;

    private readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public ApiClient(
        IAPIRequestContext context,
        ApiSettings        apiSettings,
        LoggingService     log)
    {
        _context     = context;
        _apiSettings = apiSettings;
        _log         = log;
    }

    // ------------------------------------------------------------------ //
    //  HTTP verbs                                                          //
    // ------------------------------------------------------------------ //

    public async Task<ApiResponse<T>> GetAsync<T>(
        string endpoint,
        Dictionary<string, string>? headers = null)
    {
        _log.Debug("GET {Endpoint}", endpoint);
        var response = await _context.GetAsync(endpoint,
            new APIRequestContextOptions { Headers = MergeHeaders(headers) });
        return await ParseResponseAsync<T>(response);
    }

    public async Task<ApiResponse<T>> PostAsync<T>(
        string endpoint,
        object? body    = null,
        Dictionary<string, string>? headers = null)
    {
        _log.Debug("POST {Endpoint}", endpoint);
        var response = await _context.PostAsync(endpoint,
            new APIRequestContextOptions
            {
                Headers  = MergeHeaders(headers),
                DataObject = body
            });
        return await ParseResponseAsync<T>(response);
    }

    public async Task<ApiResponse<T>> PutAsync<T>(
        string endpoint,
        object? body    = null,
        Dictionary<string, string>? headers = null)
    {
        _log.Debug("PUT {Endpoint}", endpoint);
        var response = await _context.PutAsync(endpoint,
            new APIRequestContextOptions
            {
                Headers    = MergeHeaders(headers),
                DataObject = body
            });
        return await ParseResponseAsync<T>(response);
    }

    public async Task<ApiResponse<T>> PatchAsync<T>(
        string endpoint,
        object? body    = null,
        Dictionary<string, string>? headers = null)
    {
        _log.Debug("PATCH {Endpoint}", endpoint);
        var response = await _context.PatchAsync(endpoint,
            new APIRequestContextOptions
            {
                Headers    = MergeHeaders(headers),
                DataObject = body
            });
        return await ParseResponseAsync<T>(response);
    }

    public async Task<ApiResponse<string>> DeleteAsync(
        string endpoint,
        Dictionary<string, string>? headers = null)
    {
        _log.Debug("DELETE {Endpoint}", endpoint);
        var response = await _context.DeleteAsync(endpoint,
            new APIRequestContextOptions { Headers = MergeHeaders(headers) });
        return await ParseResponseAsync<string>(response);
    }

    // ------------------------------------------------------------------ //
    //  Auth helpers                                                        //
    // ------------------------------------------------------------------ //

    /// <summary>POSTs credentials and extracts a bearer token from the response.</summary>
    public async Task<string?> GetBearerTokenAsync(
        string authEndpoint,
        string username,
        string password)
    {
        var response = await PostAsync<JsonElement>(authEndpoint, new
        {
            username,
            password
        });

        if (!response.IsSuccess) return null;

        return response.Data.TryGetProperty("token", out var token)
            ? token.GetString()
            : response.Data.TryGetProperty("access_token", out var at)
                ? at.GetString()
                : null;
    }

    // ------------------------------------------------------------------ //
    //  Internal helpers                                                    //
    // ------------------------------------------------------------------ //

    private async Task<ApiResponse<T>> ParseResponseAsync<T>(IAPIResponse response)
    {
        var rawBody     = await response.TextAsync();
        var statusCode  = response.Status;
        var headers     = response.Headers;

        _log.Debug("Response {Status} — {Length} bytes", statusCode, rawBody.Length);

        T? data = default;
        if (!string.IsNullOrWhiteSpace(rawBody) && typeof(T) != typeof(string))
        {
            try
            {
                data = JsonSerializer.Deserialize<T>(rawBody, _jsonOptions);
            }
            catch (JsonException ex)
            {
                _log.Warn("JSON deserialise failed for {Type}: {Message}", typeof(T).Name, ex.Message);
            }
        }
        else if (typeof(T) == typeof(string))
        {
            data = (T)(object)rawBody;
        }

        return new ApiResponse<T>
        {
            StatusCode = statusCode,
            Data       = data,
            RawBody    = rawBody,
            Headers    = headers.ToDictionary(
                             h => h.Key,
                             h => string.Join(", ", h.Value),
                             StringComparer.OrdinalIgnoreCase)
        };
    }

    private Dictionary<string, string> MergeHeaders(
        Dictionary<string, string>? extra)
    {
        var merged = new Dictionary<string, string>(_apiSettings.DefaultHeaders);
        if (extra is not null)
            foreach (var kv in extra)
                merged[kv.Key] = kv.Value;
        return merged;
    }
}
