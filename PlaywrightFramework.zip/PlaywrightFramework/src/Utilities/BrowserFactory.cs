using Microsoft.Playwright;
using PlaywrightFramework.Models;

namespace PlaywrightFramework.Utilities;

/// <summary>
/// Creates Playwright browser instances for Chromium, Firefox, WebKit, and Edge.
///
/// Browser selection: TEST_BROWSER env var → appsettings.{env}.json → "Chromium"
///
/// Browsers available:
///   Chromium  — Chrome-compatible, default CI browser
///   Chrome    — Real Google Chrome channel
///   Firefox   — Mozilla Firefox
///   WebKit    — Safari-compatible engine
///   Edge      — Microsoft Edge channel (Chromium-based)
///
/// Note: Playwright manages its own browser binaries.
/// Run `playwright install --with-deps` to download them.
/// Azure DevOps pipeline step handles this automatically.
/// </summary>
public sealed class BrowserFactory
{
    private readonly AppSettings _settings;

    public BrowserFactory(AppSettings settings)
    {
        _settings = settings;
    }

    // ------------------------------------------------------------------ //
    //  Public API                                                          //
    // ------------------------------------------------------------------ //

    /// <summary>Creates a browser instance based on current configuration.</summary>
    public async Task<IBrowser> CreateBrowserAsync(IPlaywright playwright) =>
        _settings.Browser.ToUpperInvariant() switch
        {
            "CHROMIUM"  => await CreateChromiumAsync(playwright),
            "CHROME"    => await CreateChromeAsync(playwright),
            "FIREFOX"   => await CreateFirefoxAsync(playwright),
            "WEBKIT"    => await CreateWebKitAsync(playwright),
            "SAFARI"    => await CreateWebKitAsync(playwright),
            "EDGE"      => await CreateEdgeAsync(playwright),
            _           => throw new NotSupportedException(
                               $"Browser '{_settings.Browser}' is not supported. " +
                               "Valid values: Chromium, Chrome, Firefox, WebKit, Edge")
        };

    /// <summary>
    /// Creates a BrowserContext with full isolation per test.
    /// Each context is equivalent to a fresh incognito session.
    /// Tracing, video, and viewport are configured here.
    /// </summary>
    public async Task<IBrowserContext> CreateContextAsync(
        IBrowser browser,
        bool enableVideo  = false,
        bool enableTrace  = false)
    {
        var contextOptions = BuildContextOptions(enableVideo);
        var context = await browser.NewContextAsync(contextOptions);

        // Apply timeouts at context level
        context.SetDefaultTimeout(       _settings.DefaultTimeoutMs);
        context.SetDefaultNavigationTimeout(_settings.NavigationTimeoutMs);

        // Start tracing if enabled (captures screenshots + snapshots + network)
        if (enableTrace)
            await context.Tracing.StartAsync(new TracingStartOptions
            {
                Screenshots = true,
                Snapshots   = true,
                Sources     = true,
                Title       = $"Trace_{_settings.Browser}_{DateTime.Now:yyyyMMdd_HHmmss}"
            });

        return context;
    }

    // ------------------------------------------------------------------ //
    //  Browser launchers                                                   //
    // ------------------------------------------------------------------ //

    private async Task<IBrowser> CreateChromiumAsync(IPlaywright playwright) =>
        await playwright.Chromium.LaunchAsync(BuildLaunchOptions());

    private async Task<IBrowser> CreateChromeAsync(IPlaywright playwright) =>
        await playwright.Chromium.LaunchAsync(BuildLaunchOptions(channel: "chrome"));

    private async Task<IBrowser> CreateEdgeAsync(IPlaywright playwright) =>
        await playwright.Chromium.LaunchAsync(BuildLaunchOptions(channel: "msedge"));

    private async Task<IBrowser> CreateFirefoxAsync(IPlaywright playwright) =>
        await playwright.Firefox.LaunchAsync(BuildLaunchOptions());

    private async Task<IBrowser> CreateWebKitAsync(IPlaywright playwright) =>
        await playwright.Webkit.LaunchAsync(BuildLaunchOptions());

    // ------------------------------------------------------------------ //
    //  Options builders                                                    //
    // ------------------------------------------------------------------ //

    private BrowserTypeLaunchOptions BuildLaunchOptions(string? channel = null)
    {
        var args = new List<string>();

        if (_settings.Headless)
        {
            // Required for CI (running in Docker / as root)
            args.Add("--no-sandbox");
            args.Add("--disable-dev-shm-usage");
            args.Add("--disable-gpu");
        }

        var options = new BrowserTypeLaunchOptions
        {
            Headless = _settings.Headless,
            SlowMo   = _settings.SlowMo,
            Args     = args,
        };

        if (!string.IsNullOrWhiteSpace(channel))
            options.Channel = channel;

        return options;
    }

    private BrowserNewContextOptions BuildContextOptions(bool enableVideo) =>
        new()
        {
            ViewportSize = new ViewportSize
            {
                Width  = _settings.ViewportWidth,
                Height = _settings.ViewportHeight
            },
            Locale             = _settings.Locale,
            TimezoneId         = _settings.TimezoneId,
            IgnoreHTTPSErrors  = _settings.IgnoreHTTPSErrors,
            RecordVideoDir     = enableVideo && _settings.VideoOnFailure
                                 ? Path.GetFullPath(_settings.VideoDirectory)
                                 : null,
            RecordVideoSize    = enableVideo && _settings.VideoOnFailure
                                 ? new RecordVideoSize
                                   {
                                       Width  = _settings.ViewportWidth,
                                       Height = _settings.ViewportHeight
                                   }
                                 : null,
        };
}
