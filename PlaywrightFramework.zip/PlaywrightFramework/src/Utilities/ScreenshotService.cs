using Microsoft.Playwright;
using PlaywrightFramework.Models;

namespace PlaywrightFramework.Utilities;

/// <summary>
/// Captures full-page screenshots using Playwright's native IPage API.
/// Screenshots are stored as PNG files and returned as paths for report attachment.
/// </summary>
public sealed class ScreenshotService
{
    private readonly AppSettings   _settings;
    private readonly LoggingService _log;

    public ScreenshotService(AppSettings settings, LoggingService log)
    {
        _settings = settings;
        _log      = log;
        Directory.CreateDirectory(Path.GetFullPath(settings.ScreenshotDirectory));
    }

    /// <summary>Captures a full-page screenshot. Returns file path or null on error.</summary>
    public async Task<string?> CaptureAsync(IPage page, string testName)
    {
        if (!_settings.ScreenshotOnFailure) return null;

        try
        {
            var timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
            var safeName  = SanitizeFileName(testName);
            var fileName  = $"{safeName}_{timestamp}.png";
            var fullPath  = Path.Combine(
                                Path.GetFullPath(_settings.ScreenshotDirectory), fileName);

            await page.ScreenshotAsync(new PageScreenshotOptions
            {
                Path     = fullPath,
                FullPage = true
            });

            _log.Info("Screenshot saved: {Path}", fullPath);
            return fullPath;
        }
        catch (Exception ex)
        {
            _log.Error(ex, "Screenshot capture failed for test: {Test}");
            return null;
        }
    }

    /// <summary>Captures a screenshot of a specific locator region.</summary>
    public async Task<string?> CaptureElementAsync(ILocator locator, string testName)
    {
        try
        {
            var timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
            var fileName  = $"{SanitizeFileName(testName)}_element_{timestamp}.png";
            var fullPath  = Path.Combine(
                                Path.GetFullPath(_settings.ScreenshotDirectory), fileName);

            await locator.ScreenshotAsync(new LocatorScreenshotOptions { Path = fullPath });
            return fullPath;
        }
        catch (Exception ex)
        {
            _log.Error(ex, "Element screenshot failed");
            return null;
        }
    }

    private static string SanitizeFileName(string name) =>
        string.Join("_", name.Split(Path.GetInvalidFileNameChars()));
}
