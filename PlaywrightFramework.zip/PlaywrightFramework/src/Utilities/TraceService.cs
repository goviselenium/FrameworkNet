using Microsoft.Playwright;
using PlaywrightFramework.Models;

namespace PlaywrightFramework.Utilities;

/// <summary>
/// Manages Playwright trace lifecycle.
///
/// Traces capture a full timeline of browser activity:
///   - Network requests and responses
///   - DOM snapshots at each action
///   - Screenshots at each step
///   - Console messages and errors
///
/// Open a saved trace with: playwright show-trace trace.zip
/// </summary>
public sealed class TraceService
{
    private readonly AppSettings    _settings;
    private readonly LoggingService _log;

    public TraceService(AppSettings settings, LoggingService log)
    {
        _settings = settings;
        _log      = log;
        Directory.CreateDirectory(Path.GetFullPath(settings.TraceDirectory));
    }

    /// <summary>Stops tracing and saves the .zip trace file. Returns the path.</summary>
    public async Task<string?> StopAndSaveAsync(IBrowserContext context, string testName)
    {
        if (!_settings.TraceOnFailure) return null;

        try
        {
            var timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            var safeName  = SanitizeFileName(testName);
            var fileName  = $"{safeName}_{timestamp}.zip";
            var fullPath  = Path.Combine(
                                Path.GetFullPath(_settings.TraceDirectory), fileName);

            await context.Tracing.StopAsync(new TracingStopOptions { Path = fullPath });

            _log.Info("Trace saved: {Path} — open with: playwright show-trace {Path}", fullPath, fullPath);
            return fullPath;
        }
        catch (Exception ex)
        {
            _log.Error(ex, "Failed to save trace for test: {Test}");
            return null;
        }
    }

    private static string SanitizeFileName(string name) =>
        string.Join("_", name.Split(Path.GetInvalidFileNameChars()));
}
