namespace PlaywrightFramework.Models;

/// <summary>Root settings model — bound from appsettings.json overlays.</summary>
public sealed class FrameworkSettings
{
    public AppSettings AppSettings { get; set; } = new();
    public Credentials Credentials { get; set; } = new();
    public ApiSettings ApiSettings { get; set; } = new();
}

public sealed class AppSettings
{
    public string Environment          { get; set; } = "Dev";
    public string Browser              { get; set; } = "Chromium";
    public bool   Headless             { get; set; } = false;
    public int    SlowMo               { get; set; } = 0;
    public int    ViewportWidth        { get; set; } = 1920;
    public int    ViewportHeight       { get; set; } = 1080;
    public int    DefaultTimeoutMs     { get; set; } = 30_000;
    public int    NavigationTimeoutMs  { get; set; } = 60_000;
    public int    ActionTimeoutMs      { get; set; } = 15_000;
    public bool   ScreenshotOnFailure  { get; set; } = true;
    public bool   VideoOnFailure       { get; set; } = false;
    public bool   TraceOnFailure       { get; set; } = true;
    public string ScreenshotDirectory  { get; set; } = "TestResults/Screenshots";
    public string VideoDirectory       { get; set; } = "TestResults/Videos";
    public string TraceDirectory       { get; set; } = "TestResults/Traces";
    public string LogDirectory         { get; set; } = "TestResults/Logs";
    public string ReportDirectory      { get; set; } = "TestResults/Reports";
    public int    MaxRetryCount        { get; set; } = 2;
    public int    ParallelWorkers      { get; set; } = 4;
    public string Locale               { get; set; } = "en-US";
    public string TimezoneId           { get; set; } = "America/New_York";
    public bool   IgnoreHTTPSErrors    { get; set; } = true;
    public string BaseUrl              { get; set; } = string.Empty;
    public string ApiBaseUrl           { get; set; } = string.Empty;
}

public sealed class Credentials
{
    public string AdminUser         { get; set; } = string.Empty;
    public string AdminPassword     { get; set; } = string.Empty;
    public string StandardUser      { get; set; } = string.Empty;
    public string StandardPassword  { get; set; } = string.Empty;
}

public sealed class ApiSettings
{
    public Dictionary<string, string> DefaultHeaders { get; set; } = new();
    public int ApiTimeoutMs { get; set; } = 30_000;
}

/// <summary>Result wrapper for typed API responses.</summary>
public sealed class ApiResponse<T>
{
    public int        StatusCode  { get; init; }
    public T?         Data        { get; init; }
    public string     RawBody     { get; init; } = string.Empty;
    public bool       IsSuccess   => StatusCode is >= 200 and < 300;
    public Dictionary<string, string> Headers { get; init; } = new();
}
